import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("시간:");
		int h = scan.nextInt();
		System.out.println("분:");
		int m = scan.nextInt();
		
		if() {
			
		}
		
	}

}
