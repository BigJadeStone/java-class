import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		//System.out.print("시간:");
		int h = scan.nextInt(); // h*60
		//System.out.print("분:"); // m
		int m = scan.nextInt();
		int chang = h*60 + m - 45;
		int fh = chang/60;
		int fm = chang%60;
		
		// h*60 + m -45 = chang 
		//  chang/60 = fh
		//  chang%60 = fm  ( 이 때 정수이기 때문에 소수부는 날아간다.)
		// h <= 23

		if(h<=23 && m<=59) {
			System.out.println( fh + " " + fm );
		} 
		
	}

}
