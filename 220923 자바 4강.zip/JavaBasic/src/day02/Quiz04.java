package day02;

import java.util.Scanner;

public class Quiz04 {
	
	public static void main(String[] args) {
		
		/*
		 * 정수를 하나 입력받습니다.
		 * 입력받은 값이 0인지, 홀수인지, 짝수인지, 음수인지 구별하는 else if문 만들어보기.
		 */
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("정수를 입력하세요\n>");
		int number = scan.nextInt();
		
		String sort = null;
		if(number == 0) {
			sort = "0";
		} else if(number <0) {
			sort = "음수";
		} else if(number %2 != 0) {
			sort = "홀수";
		} else {
			sort = "짝수";
		} 
				
		System.out.println(sort);
		
	}

}
