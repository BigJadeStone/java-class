package day02;

public class WhileEx01 {
	
	public static void main(String[] args) {
		
		
		// 콘솔에서 실행이 계속 도는것 같으면 콘솔 내에서 빨간 네모 버튼을 눌러서 중지를 해줘야함.
//		int a = 1; //제어변수 : 반복문의 횟수를 결정할 변수
//		while(a <= 10) {
//			
//			System.out.println("hello" + a);
//			
//			a++; //제어변수 조작을 통해 반복의 조건식이 언젠가 false가 되도록 처리.
//		}
		
		//누적
		int sum = 0; //누적할 변수는 무조건 while문 밖에다가 빼주는거다. 안에 있으면 계속 0으로 나옴.		
		int i = 1;
		while(i <= 10) {
			
			sum +=i; //sum = sum + i;
			
			i++;
			
		}
		
		System.out.println(sum);
		
		
		
	}

}
