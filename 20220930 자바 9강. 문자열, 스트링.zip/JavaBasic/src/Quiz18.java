import java.util.Scanner;

public class Quiz18 {

	public static void main(String[] args) {
		
		/*
		 * 랜덤한 덧셈 문제를 내는 프로그램
		 * 
		 * 반복이 실행될떄마다 1~100 사이의 랜덤한 덧셈 구문이 출력됩니다.
		 * 0을 입력받으면 프로그램을 종료합니다.
		 * 프로그램이 종료되면 정답횟수, 오답횟수를 출력하면 됩니다.
		 */
		
		Scanner scan = new Scanner(System.in);
		int good = 0;
		int bad = 0;
		System.out.println("-Game Start-");
		System.out.println();
		while(true) {
			int ran1 = (int)(Math.random()*100)+1;
			int ran2 = (int)(Math.random()*100)+1;
			System.out.println(ran1 + " + " + ran2 + " = ?" );
			System.out.println("[문제를 그만 풀려면 0을 누르시오.]");
			System.out.print(">");
			int num = scan.nextInt(); // 내가 계산한 값.
			if(num == 0) {
				System.out.println("-Adios amigo-");
				break;
			}
			
			int answer = ran1 + ran2; //두 값을 더한 값.(정답)
			if(answer != num) {
				bad++;
				System.out.println("바보입니까?");
			}
			if(answer == num) {
				good++;
				System.out.println("정답!");
			}
			System.out.println("---------------------");
		}//무한루프문
		System.out.println("<게임 종료>");
		System.out.println("정답 :" + good);
		System.out.println("오답 :" + bad);
		scan.close();
		
	}//main

}
