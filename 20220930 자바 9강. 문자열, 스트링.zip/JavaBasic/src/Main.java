import java.util.Arrays;
import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		int n = scan.nextInt(); // 5
		int[] space = new int[n];
		int sum = 0;
		
		for(int i = 0 ; i < space.length; i++) {
			int num = scan.nextInt(); // n개만큼 숫자 입력.
			space[i] = num;
		}
		
	for(int j = 0; j < space.length; j++) {
		sum += space[j];
		}
	
		System.out.println(Arrays.toString(space));
		System.out.println(sum);
		
		//char a = (char)num;
		//char[] tosum = a.toCharArray();
		
		
	}//main

}
