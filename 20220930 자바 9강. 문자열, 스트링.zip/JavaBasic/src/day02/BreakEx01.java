package day02;

public class BreakEx01 {
	
	public static void main(String[] args) {
		
//		int i = 1;
//		while(i <= 10) {
//			System.out.println(i);
//			if( i == 5)  break; // if문에서 실행할 것이 1개라면 이렇게도 사용가능.
//			i++;
//		}
		
		for(int i = 1; i <= 10; i++) {
			System.out.println(i);
			if( i == 5 ) break;
		}
		
		
		
		
	}

}
