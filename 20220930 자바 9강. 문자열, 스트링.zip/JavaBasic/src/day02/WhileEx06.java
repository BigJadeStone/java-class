package day02;

public class WhileEx06 {
	
	public static void main(String[] args) {
		
		//배열과 반복문
		//시작은 0 ~ 길이미만
		int[] arr = {1,2,3,4,5,6,7,8,9,10};
		int i = 0;
		//반복횟수 조건을 설정할 때 범위를 숫자로 정해주면 나중에 배열이 더 커질 때 
		// 자꾸 조건을 다시 설정해줘야한다. 
		// i <= arr.length - 1 이렇게 이하로 설정해줄 떄는 길이에 -1 해줘야한다. 
		// i < arr.length  길이미만. 위와 같은 의미이다.
		int sum = 0; //누적
		while(i < arr.length) {
			//System.out.println(i); 0....9
			//System.out.println(arr[i]);
			sum += arr[i];
			i++;
		}
		System.out.println("배열요소의 합:" + sum);
	}

}
