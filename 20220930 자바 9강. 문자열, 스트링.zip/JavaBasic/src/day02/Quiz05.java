package day02;

import java.util.Scanner;

public class Quiz05 {
	
	public static void main(String[] args) {
		
	/*
	 * 정수 3개를 각각 입력을 받습니다.
	 * 같은 정수는 없다고 가정을 합니다. ( 내가 치는거니까 따로 안 해도 됨.)
	 * 가장 큰값, 중간 값, 가장 작은 값을 구분해서 출력.	
	 */
		
		Scanner scan = new Scanner (System.in);
		
		System.out.print("a:");
		int a = scan.nextInt();
		System.out.print("b:");
		int b = scan.nextInt();
		System.out.print("c:");
		int c = scan.nextInt();
		
		int max = 0;
		int mid = 0;
		int mni = 0;
		
		if(a>b && a>c) {
			max = a; 
			if(b>c) {
				mid = b;
			} else if(c>b) {
				mid = c;
			} else {
				mni = b;
			}
			
		} else if(b>a && b>c) {
			max = b;
			if(a>c) {
				mid = a;
			} else if(c>a) {
				mid = c;
			} else {
				mni = a;
			}
			
		} else if(c>a && c>b) {
			max = c;
			if(a>b) {
				mid = a;
			} else if (b>a){
				mid = b;
			} else {
				mni = a;
			}
		}
			
			
			
	
		
		
		System.out.println("가장 큰값:" + max);
		System.out.println("중간 값:" + mid);
		System.out.println("가장 작은값:" + mni);
		
		
	}	
}
