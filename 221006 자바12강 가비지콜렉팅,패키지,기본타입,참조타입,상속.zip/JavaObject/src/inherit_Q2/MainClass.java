package inherit_Q2;

public class MainClass {
	
	public static void main(String[] args) {
		
		Warrior war = new Warrior("Goni");
		war.info();
		war.bash();
		war.bash();
c		
		System.out.println();
		
		Wizard wi = new Wizard("darkagfoot");
		wi.info();
		wi.iceArrow();
		
		
	}

}
