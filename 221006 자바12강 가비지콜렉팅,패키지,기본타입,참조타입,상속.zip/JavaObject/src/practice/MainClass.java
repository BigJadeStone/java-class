package practice;

public class MainClass {
	
	public static void main(String[] args) {
		
		Account acc = new Account("허태민", 1111, 9000000);
		acc.deposit(9000000);
		acc.withdraw(129000);
		System.out.println(acc.name +"님의 잔액은: " + acc.getBalance()+ "원 입니다.");
		
	}

}
