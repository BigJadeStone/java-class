package day04;

public class MethodEx05 {
	
	public static void main(String[] args) {
		
		//메서드의 (동기적)실행 - 동기적 ? 순서대로 실행한다고 생각하면 된다.
		test01();
		//메서드의 재귀적 실행 - 나 자신을 계속 실행시켜줌. 좋은 효율을 나타내는 모형은 아님. 우리는 구경만 하고 가는것.
		recursive(0);
		
		int result = fac(5);
		System.out.println(result);
		
		int sum = 1;
		for(int i = 1; i <=5; i++) {
			sum *= i;
		}
		System.out.println(sum);
		
	}//main
	
	static void test01() {
		System.out.println("1번 메서드 실행");
		test02();
		System.out.println("1번 메서드 종료");
		
	}
	static void test02() {
		System.out.println("2번 메서드 실행");
		System.out.println("2번 메서드 종료");
	}
	
	static void recursive(int a) {
		//재귀적 함수는 탈출의 구문을 반드시 명시해줘야 한다.
		if(a == 10) return;
		System.out.println(a + "번 호출");
		a++; //1증가
		recursive(a);
	}
	static int fac(int a) {
		if(a==1) return 1; //f(1) = 1
		return a*fac(a-1);
	}
	
}//class
