package quiz01;
import java.util.Arrays;
import java.util.Scanner;

public class Quiz19Solution {

	public static void main(String[] args) {
		
		/*
		 * 1. 사람수(정수)를 입력을 받습니다.
		 * 2. 입력받은 사람수 만큼 랜덤한 배열을 생성해서 중복되지 않게 랜덤값을 저장
		 * 
		 * 랜덤값 크기 1 <= x <= 사람수
		 * 힌트> 집어넣기전에 집어넣기 직전까지 중복값이 있는지 확인.
		 *
		 * 3. 중복되지 않는 배열이 생성 되었다면, ○문자를 이용해서 배열의 크기를 출력(ㅁ 한자9)
		 * 4. 스캐너를 통해서 랜덤으로 배정된 좌석을 선택할 수 있습니다.
		 * 5. 제대로 선택된 좌석이면 자리번호를 공개하고 출력.
		 * 	  제대로 선택되지 않은 좌석이면 다시 선택을 출력.
		 * 
		 * 힌트> 선택된 자리는 0으로 변경
		 * 
		 * 출력내용 ex)
		 * 배정할 좌석의 크기를 지정하세요> 5
		 * [5, 4, 3, 1, 2]
		 */

		Scanner scan = new Scanner(System.in);
		int size = scan.nextInt();
		int[] arr = new int[size];
		
		int index = 0; //현재 위치변수
		이름:while(true){//랜덤하지만 중복되지 않는 배열을 만들기 위한 무한루프 문.
			int seat = (int)(Math.random() * size) + 1; //1~size 랜덤수    , 인덱스에 넣어줄 랜덤값을 뽑음.
			
			for(int i = 0; i < index; i++){ //새 인덱스 값을 넣기 전에 바로 전 인덱스 값과 중복인지 확인.
				if(arr[i] == seat) continue 이름;// 중복이 발생한 경우. 새 인덱스에 값을 넣지 않고 랜덤다시실행으로 감.
			}
			
			arr[index] = seat; //중복이 아닌 값을 새 인덱스 값으로 넣고, 다음 인덱스로 넘어가기 위해 위치변수에 +1 해줌.
			index++; //마지막 인덱스 값이 설정되고 나면 또 인덱스가 1오름. 이 떄 반복을 끝내기 위해 아래에 브레이크를 넣어줌.
			
			if(index == size) break; // 배열의 index값은 0부터 시작이므로 배열의 index값이 배열의 크기 -1에 도달하면 배열작성완료.
		} // 중복 없는 랜덤 배열 문 작성 완료.
		//System.out.println(Arrays.toString(arr));
		
		// ------------------------------------------------------------------------
		
		//좌석 출력
		int count = 0;
		while(true) {//무한루프 실행. 이안에 크게 들어가는 프로그램 순서별 내용. 출력 출력 입력 출력.
			
			System.out.println("----------좌석 선택 프로그램----------");
			
			for(int i = 0; i < arr.length; i++) { //배열의 크기를 숫자로 나타냄. (좌석수를 숫자로 나타냄)
				System.out.printf("%d " , i+1); //%-3d = 3자리 공간을 잡고 왼쪽부터 채움.
			}
			System.out.println();//줄바꿈
			for(int i = 0; i < arr.length; i++) {// 배열의 값을 순서대로 나타내기 위한 조건.
				if(arr[i] == 0) {// 배열의 인덱스 자리의 값이 0인지 아닌지에 따라 잔여좌석수 표시다르게함. 
					System.out.printf("%s","● "); //prinf 에서 d는 정수, s는 문자열을 받음.
				} else  {
					System.out.printf("%s" , "○ ");
				}
			}
			System.out.println(); //줄바꿈
			
			System.out.print("좌석선택>"); //내가 원하는 좌석을 선택하기.
			int seat = scan.nextInt();
			
			if(arr[seat-1] == 0) { //배열의 5번째 수를 찾는다고 했을 떄 . 배열에서의 실질적인 위치는, n번째 수 -1.
				System.out.println("제대로 선택하실래요?");
			} else {
				System.out.println("선택좌석:" + arr[seat-1]);
				arr[seat-1] = 0;
				count++; //좌석 선택시 카운트증가. 무한루프문을 끝내주기 위해서 만들어 놓은 장치.
			}
			
			if(count == size) {
				System.out.println("-종료합니다-");
				break; //탈출
			}
			
		}// while
		
		
		
		
	}//main

}
