package quiz01;
import java.util.Scanner;

public class Quiz21 {
	
	public static void main(String[] args) {
		
		//메서드로 변환
		//1 - 입력받은 값을 반환시키고 (재활용)
//		Scanner scan = new Scanner(System.in);
//		int a = scan.nextInt();
//		int b = scan.nextInt();
//		//2
//		int result = a + b;
//		//3
//		System.out.println("두 수의 합:" + result);
		
		print();
		int num1 = insert();
		int num2 = insert();
		
		int result = add(num1, num2);
		showResult(result);
		
		
		
		
	}//main
	static void print() {
		System.out.println("정수 두개를 입력하세요!");
	}
	
	static int insert () {// 위에 1.
		Scanner scan = new Scanner(System.in);
		System.out.println("정수 입력>");
		int num = scan.nextInt();
		return num;
	}
	
	static int add(int num1, int num2) {// 2.
		return num1 + num2;
	}
	
	static void showResult(int result) {// 3.
		System.out.println("덧셈 결과:" + result);
	}
	
}//class
