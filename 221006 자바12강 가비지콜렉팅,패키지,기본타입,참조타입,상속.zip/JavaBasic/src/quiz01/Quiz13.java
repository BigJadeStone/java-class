package quiz01;
import java.util.Arrays;

public class Quiz13 {
	public static void main(String[] args) {
		
		//절대 중복되지 않는 3개의 숫자를 뽑기.
		/*
		 * 배열을 랜덤하게 15번정도 섞는다.
		 * 0~2번째 인덱스값을 새로운 배열에 옮겨담는다.
		 */
		int[] arr = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
		//System.out.println("random:" + ran);
		//System.out.println("배열의 길이: "+arr.length);
		System.out.println("랜덤으로 뽑은 숫자들: ");
		for(int i=0; i<arr.length; i++) {
			int ran = (int)(Math.random()*15); 
			System.out.print(ran + " ");
			// 배열의 위치값 0~14를 랜덤으로 뽑는다.
			// 위의 랜덤뽑기를 for문 밖에 만들면 랜덤뽑기가 한번밖에 실행되지 않으므로 
			// 꼭 for문 안에 만들어 줄 수 있도록 한다.
			int temp = arr[i];
			arr[i] = arr[ran];
			arr[ran] = temp;
		} 
		
		int[] newArr = new int[3];
		for(int i = 0; i<newArr.length; i++){
			newArr[i] = arr[i]; //새로운 배열에 담는다.
		}
		System.out.println(" ");
		System.out.println("3개 뽑은 값:");
		System.out.println(Arrays.toString(newArr));
		
//		int[] arr2 = {arr[0], arr[1], arr[2]} ;
//		System.out.println("");
//		System.out.println(Arrays.toString(arr2));
		
		
	}

}
