package quiz01;
import java.util.Arrays;

public class Quiz23 {
	
	public static void main(String[] args) {
		
		char[] arr = {'a', 'b', 'c', 'd', 'e', 'f'};
		System.out.println(method6(arr));
		
		int[] arr2 = {1,2,3,4,5,6,7,8,9,10};
		System.out.println(method7(arr2));
		
		String a = "고니";
		String b = "피트";
		String[]arr3 = method8(a,b);
		System.out.println(Arrays.toString(arr3));
		
	}//main
	
	static String method6(char[] a) {
		String str = "";
		for(int i = 0; i < a.length; i++) {
			str += a[i];
		}
		return str;
	}
	static int method7(int[] a) {
		int sum = 0;
		for(int i = 0; i < a.length; i++) {
			sum += a[i];
		}
		return sum;
	}
	static String[] method8(String a, String b) {
		String[] arr = { a, b };
		return arr;
	}
	
}//class
