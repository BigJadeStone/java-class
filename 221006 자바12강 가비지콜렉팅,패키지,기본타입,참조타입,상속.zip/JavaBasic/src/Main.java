import java.util.Arrays;

public class Main {
	
	public static void main(String[] args) {
		
		int[] num = {1,2,3,4,5};
		//int[] arr = solution(num);
		System.out.println(Arrays.toString(solution(num)));
		
		
	}//main
	
	public static int[] solution(int[] num_list) {
        int[] answer = {};
        int j = 0;
        for(int i = num_list.length-1; i >= 0; i--) {
        	answer[j] = num_list[i];
        	j++;
        }
        return answer;
    }
	
}
