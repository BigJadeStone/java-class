package quiz02;

public class MainClass {
	
	public static void main(String[] args) {
		
		/*
		 * Person클래스 를 파일로 정의
		 * 
		 * 멤버변수는 int age, String name
		 * 메서드 info() : String - 멤버변수를 문자열로 더해서 반환
		 * 
		 * 메인에서는 Person 객체를 2개 생성해서 각각 확인
 		 */
		
		//1. 객체생성
		Person per1 = new Person();
		//2. .로 사용
		per1.age = 18;
		per1.name = "goni";
		System.out.println(per1.info());
		
		System.out.println("===========");
		
		Person per2 = new Person();
		
		per2.age = 18;
		per2.name = "goni";
		System.out.println(per2.info());
		
		System.out.println("===========");
		
		Person per3 = new Person(18, "Goni");
		System.out.println(per3.info());
		
		System.out.println();
		
		// =================================================== //
		//멤버변수, 메서드, 생성자를 사용해서
		//현실에 찾아볼 수 있는 물건 생각해서 표현.
		//생성해서 사용 - 메서드 2개이상
		
		Pants pts = new Pants("리바이스", "생지데님", "323-448250", "Black", 34 );
		pts.info();
		System.out.println("사이즈계산기 값: " + pts.sizeCalculator(180, 90));
		
	}//main

}//class
