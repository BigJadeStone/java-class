package quiz02;

public class Person {
	
	int age;
	String name;
	
	//프로그래머가 생성자를 인위적으로 생성하면, 기본 생성자를 안 만들어 줍니다.
	//name, age를 매개변수로 받는 생성자
	Person(int year, String nic){
		age = year ;
		name = nic ;
	}
	
	//기본 생성자, 만들어주는게 좋음. 꼭!
	Person(){
		
	}
	
	
	
	String info() {
		//String a = age + " " + name;
		return age + " " + name;
	}

}
