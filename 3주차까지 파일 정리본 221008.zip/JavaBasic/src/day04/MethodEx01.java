package day04;

public class MethodEx01 {
	
	public static void main(String[] args) {
		
		//메서드는 메서드 내부에 생성 할 수 없습니다.
		//main밖에, 클래스 안에 어디서든 선언 할 수 있습니다.
		
		//메서드의 호출 - 이름()
		//System.out.println(calSum()); //calSum() 을 호출한 곳에 칼섬 메서드 안에서 내부를 실행하고 리턴 값에서 반환하기로 한 값을 반환해준다.
		int result = calSum();
		System.out.println(result);
		int result2 = calSum();
		System.out.println(result2);
		
		String result3 = ranStr(); // 메소드의 반환값이 스트링이기 때문에 변수의 타입도 스트링으로 해야지 값을 받아줄 수 있다.
		System.out.println(result3);
		
		String result4 = ranStr2();
		System.out.println(result4);
		
	}//main
	
	//반환은o 매개값x - 1부터 10까지 합
	static int calSum() {
		//1~10까지 합
		int sum = 0;
		for(int i = 1; i <= 10; i++) {
			sum += i;
		}
		
		return sum; //반환이 있으면 리턴이라는 키워드에 어떤 값을 반환하도록 만든다.
	}
	
	//반환은o 매개값x - 문자열의 결과 반환
	static String ranStr() {
		
		String str = ""; //A + B + C... + Z
		for(char c = 'A'; c <= 'Z'; c++) {
			str += c;
		}
		
		return str; //String의 기본값 null , 메서드를 만들어놓고 반환값이 아직 정해지지 않았을 때 일단 return 옆에 반환값에 다가 아무 의미없는 기본값을 설정한다.
	}
	
	//반환은o 매개값x - return키워드의 활용
	static String ranStr2() {
		
		double d = Math.random();
		
		if(d > 0.66) {
			return "가위";
		} else if( d > 0.33) {
			return "바위";
		} else {
			return "보";
		}
		
		// 위, 아래 방법은 같은 의미인데 두가지 방식으로 사용할 줄 알고 있어야한다.
		
		
		/*
		String str;
		if(d > 0.66) {
			str = "가위";
		} else if( d > 0.33) {
			str = "바위";
		} else {
			str = "보";
		}
		return str;
		 */
		
	}
}//class
