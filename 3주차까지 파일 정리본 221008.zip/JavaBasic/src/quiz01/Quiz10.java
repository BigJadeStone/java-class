package quiz01;

public class Quiz10 {
	public static void main(String[] args) {
		
		//금액을 가장 큰 금액부터 나누어서 각 동전별로 몇개가 나와야 하는지 출력.
		int[] arr = {1000, 500, 100, 50, 10};
		int money = 17780;
		//힌트 % 나머지, /몫을 잘 구하면 된다.
		/*
		 * int num = money/arr[i]; 는 1000의 갯수,500의 갯수 ....
		 *  그다음은 money%num 에다가 /arr[i] -> 그다음 인덱스값 해주면 됨.    
		 */
		int i = 0;
		while(i < arr.length) {
			//int num = money/arr[i];
			System.out.println(arr[i] + "의 합: " + money/arr[i] + "개");
			money %= arr[i]; //money= money%arr[i];
			i++;
		}
		
	}

}
