package quiz01;
import java.util.Scanner;

public class Quiz16 {
	public static void main(String[] args) {
		
		/*
		 * 정수형태로 입력을 2개 받습니다.
		 * 첫번째=가로길이, 두번째=세로길이
		 * 가로=5 , 세로=4
		 * 입력받은 가로,세로 길이의 사각형을 출력하면 됩니다.
		 * 단, 윤곽만 출렵합니다.
		 * 
		 * 힌트->1행,마지막행,1열,마지막열만 출력, 공백도 문자임.
		 */
		//센세 풀이.
		Scanner scan = new Scanner(System.in);
		System.out.print("가로>");
		int w = scan.nextInt();
		System.out.print("세로>");
		int h = scan.nextInt();
		String star = "*";
		
		for(int i = 1; i<=h; i++) {//세로(열)
			for(int j = 1; j <= w; j++) {//가로(열)
				if( i == 1 || i == h || j == 1 || j== w) { //1행, 마지막행, 1열, 마지막열
					System.out.print("*");
				} else {
					System.out.print(" ");
				}
			}
			System.out.println("");
		}
		
		
		
		
//		*성수님 풀이.
//		System.out.print("가로>");
//		int a = scan.nextInt();
//		System.out.print("세로>");
//		int b = scan.nextInt();
//		String star = "*";
//		for(int i=1; i<=b; i++) { // 행 갯수 설정.   
//			if(i==1 || i==b ) { //행의 첫줄과 끝줄인 상황.
//			for(int j=1; j<=a; j++) {//별을 가로 수 만큼 찍기.
//					System.out.print(star);
//				}
//			System.out.println(); //줄 바꿔주기.
//			} else { //행이 첫번째랑 끝 줄이 아닌 상황.
//				for(int j=1; j<=a; j++) {//열에대한 설정.
//					if(j==1 || j==a) {//열이 첫줄과 끝줄일 때
//						System.out.print(star);
//					} else {//열이 처음과 끝줄이 아닐 때
//						System.out.print(" ");
//					}
//				}
//				System.out.println("");
//			}
//			//System.out.println("");
//		}
		
		
		
		
		
	}

}
