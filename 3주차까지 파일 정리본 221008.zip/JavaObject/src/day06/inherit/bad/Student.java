package day06.inherit.bad;

public class Student {
	
	String name;
	int age;
	String studentid; //학번
	
	String info() {
		return "이름:" + name + ", 나이:" + age;
	}

}
