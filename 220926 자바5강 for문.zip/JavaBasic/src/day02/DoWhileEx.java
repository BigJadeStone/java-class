package day02;

public class DoWhileEx {
	public static void main(String[] args) {
		
		//while문이 do~while 대체 할 수 있어서 많이 사용하지 x 
		//do ~ while 문은 조건이 false어도 무조건 1번은 실행함.
		
		//1~10합
//		int sum = 0;
//		 
//		int i = 1;
//		while(i <= 10) {
//			sum += i;
//			i++;
//		}
//		System.out.println(sum);
		
		int sum = 0;
		int i = 1;
		do {
			sum += i;
			i++;
		}while(false);  //(i <= 10);
		System.out.println(sum);
	}

}
