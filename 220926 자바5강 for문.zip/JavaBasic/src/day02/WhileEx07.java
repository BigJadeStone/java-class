package day02;

public class WhileEx07 {
	
	public static void main(String[] args) {
		
		//최대값을 찾아라
		int[] arr = {50,30,40,60,70,90,100,110,20};
		
		int max = arr[0]; // 최대값을 저장할 변수.
		int i = 0;
		while(i < arr.length) {
			//조건 -> arr[i]가 max보다 크면 arr[i]를 max에게 저장.
			if(arr[i] > max) {
				max = arr[i];
			}
			i++;
		}
		System.out.println("최대값 : " + max);
		System.out.println("----------------------------------------------");
		//arr의 최소값을 찾아보세요.
		int min = arr[0]; // 최소값을 저장할 변수.
		int j = 0; // 왜 위에 i 변수를 그대로 사용하려고 하면 반복문이 돌지 않는지 생각해보기.
				   // 이유: 위에서 i 변수는 이미 증가가 다 되었기 때문에 아래 반복문에서 그대로 사용하면 안됨.
		while(j < arr.length) {
			if(arr[j] < min) {
				min = arr[j];
			}
			j++;
		}
		System.out.println("최소값 : " + min);
		
	}

}
