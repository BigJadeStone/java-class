
public class Main {
	
	public static void main(String[] args) {
		
		
		System.out.println("         ,r'\"7\r\n"
				+ "r`-_   ,'  ,/\r\n"
				+ " \\. \". L_r'\r\n"
				+ "   `~\\/\r\n"
				+ "      |\r\n"
				+ "      |");
		
	}

}
