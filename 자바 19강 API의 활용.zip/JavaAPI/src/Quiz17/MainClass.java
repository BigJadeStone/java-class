package Quiz17;

public class MainClass {
	public static void main(String[] args) {
		
		//문제1.
		String rrn;
		try {
			rrn = Validation.masking("950525-1328972");
			System.out.println(rrn);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		//문제2
		String answer = Validation.palindromeCheck("아 좋다 좋아");
		System.out.println(answer);
		
		
		
		
		
		
	}//main

}//class
