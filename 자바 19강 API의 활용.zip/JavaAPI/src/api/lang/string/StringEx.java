package api.lang.string;

import java.util.Arrays;

public class StringEx {
	
	public static void main(String[] args) {
	
	
	String s = "홍길동";
	char a = s.charAt(0);
	System.out.println(a);
	
	//길 문자를 찾으면 위치반환, 못찾으면 -1반환
	int index = s.indexOf("길");
	System.out.println("길 위치:" + index);
	
	//repalce - 원본문자는 유지.
	//CharSequence 이거는 그냥 문자열이라고 보면된다.
	String result = s.replace("길", "");
	System.out.println("결과 : " + result);
	System.out.println("원본문자열:" + s);
	
	//substring
	String s2 = "오늘은 날씨가 추워요";
	String result2 = s2.substring(4);
	System.out.println(result2); //인덱스4 미만 절석
	
	String result3 = s2.substring(4,7); // 머머 이상~ 머머 미만 값 출력.
	System.out.println(result3);
	
	//trim - 앞뒤공백제거
	System.out.println("        홍길동 ".trim() );
	
	//split - 문자열 자르기
	String[] result4 = s2.split(" ");
	System.out.println(Arrays.toString(result4));
	
	String[] result5 = "010-1234-3456".split("-", 2);
	System.out.println(Arrays.toString(result5));
	
	//문자열 포함여부
	if(s.contains("홍")) {
		System.out.println("홍 이 포함됨");
	}
	
	
	String result6 = String.copyValueOf(new char[] {'a','b','c'});
	System.out.println(result6);
	
	String result7 = String.valueOf(3);
	System.out.println("문자열바뀐결과:" + result7);
	
	
	
	
	
	}
	
}
