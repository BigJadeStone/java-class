package api.lang.object;

public class Person /*extends Object*/ implements Cloneable{
	
	private String name;
	
	public Person(String name) {
		this.name=name;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	//alt + shift + s 해서 나오는 것중 generate toString 을 써서 생성한 오버라이딩구문.
	@Override
	public String toString() {
		return "Person [name=" + name + "]";
	}

	//멤버 변수명이 같으면 트루 반환하도록 만들기.
	@Override
	public boolean equals(Object obj) {
		
		if(obj instanceof Person) {
			Person p = (Person)obj;
			String n = p.getName();
			
			if(n.equals(this.name)) {
				System.out.println("이름이 같음");
				return true;
			}
		}
		return super.equals(obj);
	}

	
	//clone메서드를 사용하고 싶다면 override
	@Override
	protected Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	
	
	
	
	
	
	
}
