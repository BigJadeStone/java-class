package day09.inter.basic2;

public interface BasicInter {
	
	void insert(int a);
	void info();
	String getInfo();
	int delete(int a);
	
}
