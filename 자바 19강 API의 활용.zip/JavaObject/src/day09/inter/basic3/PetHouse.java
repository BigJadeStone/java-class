package day09.inter.basic3;

public class PetHouse {
	
	//1. IPet 타입을 매개변수로 받아서 기능을 출력하는 메서드
	public static void petPrint(IPet a) {
		a.play();
	}
	
	
	//2. IPet[] 타입을 매개변수로 받아서, 배열내부 pet들의 play기능을 실행
	public static void arr2Print(IPet[] arr2) {
//		 for(IPet i : arr2) {
//			 i.play();
//		 }
		for(int i = 0; i < arr2.length; i++) {
			arr2[i].play();
		}
		
	}
	
	
	
	
	
}
