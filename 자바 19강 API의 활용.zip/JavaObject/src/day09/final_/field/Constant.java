package day09.final_.field;

public class Constant {
	
	public static final double PI = 3.14;
	public static final long EARTH_RADIUS = 6371L;
	public static final int O2 = 32; 
	
	
	
}
