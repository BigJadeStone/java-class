package day09.abs.good;

public class MainClass {
	
	public static void main(String[] args) {
		
		//1. 추상클래스는 객체 생성이 안됩니다.
		// 반드시 자식으로 구체화 됩니다/
		
		//Store s = new Store(); // 이거는 안됨.
		//SeoulStore s = new SeoulStore();
		Store s = new BusanStore(); //-> 클래스 추상화 , new SeoulStore();
		s.apple();
		s.melon();
		s.orange();
		System.out.println(s.getName());//상속받은
		
	}
	
}
