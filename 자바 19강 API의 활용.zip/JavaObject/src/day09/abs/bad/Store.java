package day09.abs.bad;

public class Store {
	//부모클래스
	public void apple() {System.out.println("자식에서 재정의 하세요");}
	public void melon() {System.out.println("자식에서 재정의 하세요");}
	public void orange() {System.out.println("자식에서 재정의 하세요");}
		
	
	

}
