package day06.inherit.good;

public class Student extends Person{
	
	String studentid; //학번
	
	

}
