package Quiz16;

import java.util.Scanner;

public class MainClass {
	public static void main(String[] args) {
		
//		/*
//		 * up down게임
//		 */
//		Scanner scan = new Scanner(System.in);
//		
//		int n = (int)(Math.random()*100+1);
//		int count = 0;
//		while(true) {
//			try {
//				int answer = scan.nextInt();
//				if(n < answer) {
//					count++;
//					System.out.println("더 작은 수를 입력하세요");
//				} else if(n > answer) {
//					count ++;
//					System.out.println("더 큰 수를 입력하세요");
//				} else if(n == answer) {
//					count++;
//					System.out.println( answer + "정답입니다");
//					System.out.println("시도횟수 : " + count);
//					break;
//				}
//				
//			} catch (Exception e) {
//				System.out.println("숫자를 입력해주세요");
//				scan.nextLine(); //엔터값 제거
//				count ++;
//			}
//		}
		
		
		
		
		
		
		
		
		
		
		
		
		
	}//main

}//class
