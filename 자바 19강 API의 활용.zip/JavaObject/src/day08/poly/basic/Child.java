package day08.poly.basic;

public class Child extends Parent{

	//alt + shift + s -> 오버라이딩도 자동으로 할 수 있음.
	@Override
	public void method02() {
		System.out.println("오버라이드 된 2번 메서드");
	}
	
	public void method03() {
		System.out.println("자식의 3번 메서드");
	}
	
}
