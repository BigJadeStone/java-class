package Quiz11;

public class KeyBoard {

	public void info() {
		System.out.println("----키보드 정보----");
		System.out.println("from 삼성");
	}
}
