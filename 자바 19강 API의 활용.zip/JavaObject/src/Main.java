import java.util.Arrays;

public class Main {
	
	public static void main(String[] args) {
		
		int[]array = {9,10,11,8};
		System.out.println(Arrays.toString(solution(array)));
		
		
		
	}//main
	
    public static int[] solution(int[] array) {
        int[] answer = new int[2];

        for(int i=0; i < array.length-1; i++) {
        	for(int j = 1; j<array.length; j++) {
        		if(array[i]<array[j]) {
        			answer[0] = array[j];
        		} else if(array[i]>array[j]){
        			answer[0] = array[i];
        		}
        	}
        }
        
        
        for(int i = 0; i < array.length; i++) {
        	if(array[i] == answer[0]) {
        		answer[1] = i;
        		break;
        	}
        }
        
        return answer;
    }
   
	
	
}//class
