package day07.modi.protec.pac2;

public class MainClass {
	
	public static void main(String[] args) {
		
		MainClass a = new MainClass();
		
	}

}
