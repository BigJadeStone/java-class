package Quiz07;

public class PrintArray {
	
	String toArray(int[] arr) {
		String str = "[";
		for(int i =0 ; i< arr.length; i++) {
			if(i>= 0 && i<arr.length-1) {
				str +=  arr[i] + ",";
			} else {
				str += arr[i];
			}
		}
		str += "]";
		return str;
	}
	String toArray(char[] arr) {
		String str = "[";
		for(int i =0 ; i< arr.length; i++) {
			if(i>= 0 && i<arr.length-1) {
				str +=  arr[i] + ",";
			} else {
				str += arr[i];
			}
		}
		str += "]";
		return str;
	}
	
	String toArray(String[] arr) {
		String str = "[";
		for(int i =0 ; i< arr.length; i++) {
			if(i>= 0 && i<arr.length-1) {
				str +=  arr[i] + ",";
			} else {
				str += arr[i];
			}
		}
		str += "]";
		return str;
	}
	
	

}
