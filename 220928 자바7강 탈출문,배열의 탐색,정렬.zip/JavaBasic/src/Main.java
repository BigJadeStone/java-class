import java.util.Arrays;
import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		//백준 반복문 9번 문제임. x보다 작은 수 출력하기.
		
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt(); //정수 n개로 이루어진 수열a
		int x = scan.nextInt(); //x 보다 작은수를 출력할 것임.
		int[] arr = new int[n];
		/*
		 * 이 문제 매스랜덤이 아니라 배열에 0~n 의 정수를 섞어주는 작업이 필요해보임.
		 * 정수 n개를 섞어 준다. 변수간에 스왚이 필요해 보임. 
		 */
		
		for(int i = 0; i < arr.length; i++) {
			//우선 배열을 주어진 정수 n개까지 만들어주는 식을 작성.
			int num = scan.nextInt();
			arr[i] = num; // 정수n만큼 숫자의 입력을 반복.
			if(arr[i] < x) {
				System.out.print(arr[i] + " ");
			}
		}//바깥 for문 
		
//		for(int i = 0; i < arr.length ; i++) {
//			//정수 n개로 이루어진 수열 arr 설정.
//			int ran = (int)(Math.random()*n)+1;
//			//arr[0] = 1 이 되게끔 함. 적어도 x보다 작은수가 하나는 존재해야하기 때문.
//			if(i==0) {
//				a[i] = 1;
//			} else {
//				arr[i] = ran;
//			}
//			//x 보다 작은수를 출력.
//			if(arr[i] < x) {
//				System.out.print(arr[i] + " ");
//			}
//			
//		}
		
		
		
	}//main

}
