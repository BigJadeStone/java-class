package day02;

public class EnhanceForEx {
	
	public static void main(String[] args) {
		
		int[] arr = {1,2,3,4,5};
		
//		//일반 for
//		for(int i = 0; i < arr.length; i++) {
//			System.out.println(i);
//		}
		
		//향상된for문.
		for(int a : arr) {
			System.out.println(a);
		}
		
		System.out.println("---------------------------------------------");
		
		String[] sArr= {"월", "화", "수", "목", "금", "금", "금"};
		for(String s : sArr) {
			System.out.println(s);
		}
		
		System.out.println("-------------------------------------------");
		
		//배열 요소들의 합계와 평균을 소수 2자리까지만 출력
		int[] score = {34, 54, 23, 53, 65};
		float sum = 0; //이렇게 sum, 즉 합계 변수는 밖에 만들어줘야한다.
		float equal = 0; // 평균 변수도 밖에 만들어줘야하기는 마찬가지.
		
		for(int num : score) {
			//합계
			sum += num; //누적
		}	//평균
			//equal = sum/score.length;
			//출력
			//System.out.println("합계: " + plus +"\n"+ "평균: " + equal );
			System.out.println("합계:" + sum);
			System.out.println("평균" + (double)sum/score.length); 
			System.out.printf("평균:%.2f\n", + (double)sum/score.length); 
			
			/*
			 * 위에 소수부2까지 표현하는 법은 총 3가지가있음.
			 * 1. printf 사용하는 법.
			 * 2. 문자열로 치환해주는 법.
			 */
			
			
			
		
		
		
		
		
	}

}
