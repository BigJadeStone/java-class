package day02;

import java.util.Arrays;

public class ForEx04 {

	public static void main(String[] args) {
		
//     #변수의 swap
//		int x = 10;
//		int y = 5;
//		위 두가지 변수의 값을 서로 바꾸어 주기 위해 
//		temp라는 변수 즉 상자를 하나 더 만든다.
//		
//		int temp = x;
//		x = y;
//		y = temp;
//		x를 템프에 넣고 y를 x에 넣고 템프를 y에 넣는다.
//		
//		System.out.println("X:" + x + ", Y:" + y);
		
		//배열의 swap - 배열을 1번 랜덤하게 변경.
		int[] arr = {1,2,3,4,5,6,7,8,9,10};
		
		int ran = (int)(Math.random()*9)+1; //0~9라는 숫자를 랜덤으로 뽑는다.
											//0~9는 arr[0~9] 로 사용할것.
		int temp = arr[0]; //temp라는 빈 상자를 하나 만든다. 변수 값 swap를 위해.
		arr[0] = arr[ran];
		arr[ran] = temp;
		// int temp = arr[0] = arr[ran] = temp 이렇게 생각하면 됨.
		System.out.println(Arrays.toString(arr));
		
	}

}
