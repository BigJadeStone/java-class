import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt(); //정수 n개로 이루어진 수열a
		int x = scan.nextInt(); //x 보다 작은수를 출력할 것임.
		int[] a = new int[n];
		
		for(int i = 1; i <= n; i++) {
			//정수 n개로 이루어진 수열 a 설정.
			int ran = (int)(Math.random()*9999)+1;
			a[i] = ran;
			//x 보다 작은수를 출력.
			if(a[i] < x) {
				System.out.print(a[i] + " ");
			}
			
		}
		
		
		
	}

}
