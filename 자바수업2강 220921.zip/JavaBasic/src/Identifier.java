
public class Identifier {
	
	public static void main(String[] args) {
		
		int age = 10; //o
		int Age = 20;
		int agE = 30;
		
		System.out.println(age);
		System.out.println(Age);
		System.out.println(agE);
		
		int phonenumber = 4;
		int phoneNumber = 5; //o
		
		System.out.println(phonenumber);
		System.out.println(phoneNumber);
		
		int 1num = 1;
		
		int num1 = 1;
		int num2 = 2;
		
		int class = 10;
		int public = 20;
		
		
		
	}

}
