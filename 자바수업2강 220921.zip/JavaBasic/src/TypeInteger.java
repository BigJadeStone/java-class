
public class TypeInteger {
	
	public static void main(String[] args) {
		
		//byte, short, int, long 
		byte a = 127; // 가장 큰 정수의 값으로 127까지만 가능.
		byte b = -128;
		
		short c = 32767;
		short d = -32768;  // 크기를 외울필요 없음. 대략적으로 이정도구나 하고 알고있으면 됨.
		
		int e = 2147483647; 
		int f = -2147483648; 
		
		long g = 123123123123123123L; //기본 정수로는 int 를 나타내기에. long 은 l(대소문자구분 필요x)을 붙임
		System.out.println(g);
		
		/*
		 * 2진수 저장할 때는 0b를 붙임
		 * 8진수는 저장할 때 0을 붙임
		 * 16진수 저장할 때는 0x를 붙임
		 */
		
		int bin = 0b1010; //2진수
		int octa = 064; //8진수
		int hexa = 0xAC00; //16진수
		
		System.out.println("이진수 1010은:" + bin + "입니다"); // 중간에 + 를 붙여줘야됨.
		System.out.println("팔진수 64는:" + octa + "입니다" );
		System.out.println("십육진수 AC00은:" + hexa + "입니다");
		
		System.out.println("---------------------------------");
		
		float f1 = 3.14F; //실수형에서는 기본이 double 이기 때문에 float를 나타날 때는 F를 붙임.
		double d1 = 3.14; 
		
		float f2 = 3.14159233333F; //7자리까지 유효함
		double d2 = 3.14159233333; //15자리까지 유효함
		
		System.out.println(f2);
		System.out.println(d2);
		
		System.out.println("-------------------------");
		//e표기법
		float f3 = 314.15e-2F; //10 -2승
		double d3 = 0.031415e2; //10 2승
		
		System.out.println(f3);
		System.out.println(d3);
		
		System.out.println("-----------------------------");
		boolean bool1 = true;
		boolean bool2 = false;
		
		System.out.println(bool1);
		
		
	}

}
