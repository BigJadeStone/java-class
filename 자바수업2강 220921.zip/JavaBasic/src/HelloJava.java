
public class HelloJava {

	public static void main(String[] args) {
		
		/*
		 * 여러줄 주석입니다
		 */
				
		System.out.print("hello world\n"); // \n은 줄바꿈입니다
		System.out.print("안녕하세요");
	}
}
