package day09.inter.basic3;

public class Dog extends Animal implements IPet{
	
	@Override
	public void play() {
		System.out.println("개는 방에서 놀아요");
	}

	public void eat() {
		System.out.println("개는 사료를 먹어요");
	}
	
	
	
}
