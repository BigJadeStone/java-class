package day09.inter.basic2;

public class Basic implements BasicInter{

	@Override
	public void insert(int a) {
		int b = a;
		System.out.println("info...............");
	}

	@Override
	public void info() {
		System.out.println("info...............");		
	}

	@Override
	public String getInfo() {
		System.out.println("info...............");
		return "getInfo";
	}

	@Override
	public int delete(int a) {
		System.out.println("delete...............");
		return 0;
	}
	//클래스가 가져야할 메서드를 interface에 정의
	
	
	
	
}
