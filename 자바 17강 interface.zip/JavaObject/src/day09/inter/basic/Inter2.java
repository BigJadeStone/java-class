package day09.inter.basic;

public interface Inter2 {

	void method02();
}
