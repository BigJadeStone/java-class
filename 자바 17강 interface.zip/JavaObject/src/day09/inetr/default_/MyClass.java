package day09.inetr.default_;

public class MyClass implements MyInter{

	@Override
	public void some1() {
		System.out.println("some1 오버라이딩");
	}
	
	
	
	

}
