package day09.final_.method;

public class Child extends Parent{
	
	public void method01() {}
	//public void method02() {}//오버라이딩 금지
	
}
