package day07.encap.good;

public class MainClass {
	
	public static void main(String[] args) {
		
		MyBirth me = new MyBirth();
		
		me.setYear(2022);//set
		int year = me.getYear();//get
		System.out.println("년도 :" + year);
		
		me.setMonth(10);//set
		int month = me.getMonth();//get
		System.out.println("달: " + month);
		
		me.setDay(11);//set
		int day = me.getDay();//get - 조회
		System.out.println("일: " + day);
		
		me.setSsn("2052351564897");//set
		String ssn = me.getSsn();//get - 조회
		System.out.println("주민번호:" + ssn);
		
		
		
	}//main

}
