package practice;

public class Main {
	
	public static void main(String[] args) {
		
		
		
		
	}//main
	
	
	//10인분 - 음료수 1 서비스
	//양꼬치 1인분 12,000원  음료수 2,000원
	//양꼬치 n  음료수 k 
	// 총 얼마내야되는지 ? 
	public int solution(int n, int k) {
        int answer = 0;
        
        
        
        return answer;
    }
	
	
	
}//class
