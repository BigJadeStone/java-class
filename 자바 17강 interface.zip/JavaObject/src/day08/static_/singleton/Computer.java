package day08.static_.singleton;

public class Computer {
	
	public static int a = 10;
	
	//정적초기화자 - 1회만 실행됨
	static {// 옆에 이 키워드가 붙으면은 단 1번만 실행함.
		System.out.println("단 1번 실행 - 클래스명이 호출될 때");
	}

}
