package day08.poly.instanceof_;

public class Person extends Object { //부모클래스로 사용

	String name;
	int age;
	//기본생성자
//	Person() {
//		this("홍길동", 1); //두개짜리 생성자 호출
//	}
	
	Person(String name) {
		this(name, 1); //두개짜리 생성자 호출
	}
	
	Person(String name, int age) {
		super();
		this.name = name.toUpperCase();
		this.age = age;
		//System.out.println("100줄짜리 코드.....");
	}
	
	String info() {
		return "이름:" + name + ", 나이:" + age;
	}
	
}
