package day08.static_.basic;

public class MainClass {
	public static void main(String[] args) {
		
		//PrintArray print = new PrintArray();
		
		int[] i = {1,2,3,4,5,6};
		System.out.println(PrintArray.toArray(i));
		char[] c = {'a', 'b', 'c', 'd'};
		System.out.println(PrintArray.toArray(c));
		String[] s = {"도내s급고니" , "딸각풋", "진진빠더", "달미권", "자이먼","재미니스마인타그","해피피트"};
		System.out.println(PrintArray.toArray(s));
	}//main

}//class
