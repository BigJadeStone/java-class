package day08.static_.basic;

public class PrintArray {
	
	private PrintArray() {}//객체생성불가
	
	 public static String toArray(int[] arr) {
		String str = "[";
		for(int i =0 ; i< arr.length; i++) {
			if(i>= 0 && i<arr.length-1) {
				str +=  arr[i] + ",";
			} else {
				str += arr[i];
			}
		}
		str += "]";
		return str;
	}
	public static String toArray(char[] arr) {
		String str = "[";
		for(int i =0 ; i< arr.length; i++) {
			if(i>= 0 && i<arr.length-1) {
				str +=  arr[i] + ",";
			} else {
				str += arr[i];
			}
		}
		str += "]";
		return str;
	}
	
	public static String toArray(String[] arr) {
		String str = "[";
		for(int i =0 ; i< arr.length; i++) {
			if(i>= 0 && i<arr.length-1) {
				str +=  arr[i] + ",";
			} else {
				str += arr[i];
			}
		}
		str += "]";
		return str;
	}
	
	

}
