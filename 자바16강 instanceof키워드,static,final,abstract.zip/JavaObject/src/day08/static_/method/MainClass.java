package day08.static_.method;

public class MainClass {
	
	public static void main(String[] args) {
		
		Count c = new Count();
		c.some1(); //일반메서드
		c.some2(); //정적메서드 -> 스태틱은 이거 만들필요없음. 이렇게 쓰는건 잘못쓰는거라고 아래 노란줄로 경고표시뜸. 그냥 클래스.메서드 부르면 됨.
		
		//정적 메서드 - 객체생성 없이 사용
		Count.some2(); 
		//현재 b는? 3
		
		//main은 static 메서드이기 때문에 같은 스태틱 메서드인 a메서드를 객체생성 없이 사용가능.
		a();
		
		//static사용방법
		Math.random();
		Integer.parseInt("3");
		
		
		
		
	}
	
	public static void a() {
		
	}
	
}
