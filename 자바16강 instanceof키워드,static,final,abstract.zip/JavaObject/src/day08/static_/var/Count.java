package day08.static_.var;

public class Count {

	public int a;
	public static int b;
	
}
