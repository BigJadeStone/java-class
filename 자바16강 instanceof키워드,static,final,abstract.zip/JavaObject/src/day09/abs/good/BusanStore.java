package day09.abs.good;

public class BusanStore extends Store{

	@Override
	public void apple() {
		System.out.println("부싼사과 500원");
	}

	@Override
	public void melon() {
		System.out.println("부싼멜론 600원");
	}

	@Override
	public void orange() {
		System.out.println("부싼오렌지 700원");
	}
	
	

}
