package Quiz05;

public class Account {
	
	String name;
	int password;
	int balance;
	
	Account(){
		
	}
	
	Account(String n, int p, int b){
		name = n;
		password = p;
		balance = b;
	}
	//입금기능
	void deposit(int insert) {
		balance += insert;
		System.out.println(insert + "원이 입금되었습니다.");
	}
	//출금기능
	void withDraw(int out) {
		balance -= out;
		System.out.println(out + "원이 출금되었습니다.");
	}
	//잔액 조회
	int getBalance() {
		return balance;
	}
	
}//class
