package Quiz11;

public class MainClass {
	
	public static void main(String[] args) {
		
		Computer com = new Computer();
		com.computerInfo();
		
//		com.getKeyBoard().info(); //getter 메서드는 클래스를 가져온것. 즉 클래스 참고라고 보고 . 찍고 클래스 안에 기능을 사용하면됨.
//		com.getMouse().info();
//		com.getMonitor().info();
		
		Monitor m = com.getMonitor();
		m.info();
		
	}

}
