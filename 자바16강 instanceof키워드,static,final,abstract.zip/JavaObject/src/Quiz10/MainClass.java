package Quiz10;

import java.util.Arrays;
import java.util.Scanner;

public class MainClass {
	public static void main(String[] args) {
		
	
	User u = new User("홍길동", 20, 123123);
//	u.setName("홍길동");
//	u.setAge(20);
//	u.setRrn(123123);
//	String name = u.getName();
//	int age = u.getAge();
//	int rrn = u.getRrn();
	System.out.println("이름:" + u.getName() +" "+ "나이:" + u.getAge() +" "+ "rrn:" + u.getRrn());
	
	User u2 = new User("김길동", 30 , 456789);
	//User[] arr = new User[2];
	u2.arr[0] = u; 
	u2.arr[1] = u2; 
	for(User i : u2.arr) {
		System.out.println("이름:" + i.getName());
		System.out.println("나이:" + i.getAge());
		System.out.println("rrn:" + i.getRrn());
	}
	
	//문제3.
	Scanner scan = new Scanner(System.in);
	int i =0;
	while(i<u.arr2.length) {
		String name = scan.next();
		int age = scan.nextInt();
		int rrn = scan.nextInt();
		User user = new User(name, age, rrn);
		u.arr2[i] = user;
		i++;
	}
	System.out.println(Arrays.toString(u.arr2));
	
	for(User v : u.arr2) {
		System.out.println("이름:" + v.getName());
		System.out.println("나이:" + v.getAge());
		System.out.println("rrn:" + v.getRrn());
	}
	
	}//main
	
}//class
