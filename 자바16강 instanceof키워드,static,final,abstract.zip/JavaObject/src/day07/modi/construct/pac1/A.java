package day07.modi.construct.pac1;

public class A {
	
	//생성자
	public A(int i){}
	A(boolean b){}
	private A(String s){}
	
}
