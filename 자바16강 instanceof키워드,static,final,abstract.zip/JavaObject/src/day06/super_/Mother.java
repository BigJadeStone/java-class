package day06.super_;

public class Mother extends Person {
	
	//생략
	Mother() {
		super("김xx", 20);
	}
	
}
