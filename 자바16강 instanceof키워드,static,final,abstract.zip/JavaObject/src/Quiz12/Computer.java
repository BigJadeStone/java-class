package Quiz12;

public class Computer extends Product {
	//가격 600원 이름은 com
	//get, set메서드는 자동으로 상속됩니다
	
	public Computer() {
		super(600, "com");
	}
}
