package Quiz12;

public class MainClass {
	public static void main(String[] args) {
		
		//카트객체
		MyCart cart = new MyCart(2000);
		
		Computer com = new Computer();
		Radio ra = new Radio();
		Tv tv = new Tv(); 
		
		cart.buy(new Computer());
		cart.buy(new Radio());
		cart.buy(new Tv());
		cart.buy(com);
		cart.buy(tv);
		
		
		
	}//main
	
}//calss
