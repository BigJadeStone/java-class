package Quiz12;

public class MainClass {
	public static void main(String[] args) {
		
		MyCart cart = new MyCart(1800);
		Computer com = new Computer();
		Radio ra = new Radio();
		Tv tv = new Tv(); 
		
		cart.buy(com);
		cart.buy(ra);
		cart.buy(tv);
		cart.buy(com);
		cart.buy(tv);
		
		
		
	}//main
	
}//calss
