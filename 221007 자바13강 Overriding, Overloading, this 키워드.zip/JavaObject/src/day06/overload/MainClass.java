package day06.overload;

public class MainClass {

	public static void main(String[] args) {
		
		Basic b = new Basic();
		
		b.input(1);
		b.input("홍길동");
		b.input("a", 1);
		b.input(1, "a");
		b.input(100, 100, 1);
		
		//인트배열, 실수배열, 문자열배열
		
	}
	
}
