package day06.override;

public class MainClass {

	public static void main(String[] args) {
		
		Child c = new Child();
		c.method01();
		c.method02();
		c.method03();
		
	}
	
}
