package Quiz05;

import java.util.Scanner;

public class MainClass {
	
	public static void main(String[] args) {
		
//		Scanner scan = new Scanner(System.in);
		
		Account acc = new Account("허태민", 1111, 9000000);
		acc.deposit(9000000);
		System.out.println(acc.name +"님의 잔액은: " + acc.getBalance()+ "원 입니다.");
		
//		System.out.print("비밀번호를 입력하세요 : ");
//		int ps = scan.nextInt();
//		if(acc.password == ps) {
//			acc.withDraw(129000);
//		} else {
//			System.out.println("비밀번호가 틀렸습니다.");
//		}
		System.out.println("================================");
		MyAccount my = new MyAccount("허태민", 8282, 1000000);
		my.withDraw(10000);
		System.out.println(acc.name +"님의 잔액은: " + acc.getBalance()+ "원 입니다.");
		
	}

}
