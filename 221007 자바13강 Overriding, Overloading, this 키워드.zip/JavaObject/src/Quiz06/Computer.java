package Quiz06;

public class Computer extends Calculator{
	
	//오버라이딩 
	double circle(int r) {
		return Math.PI*r*r; 
	}
	//오버로딩 정사각형 넓이 구하기
	double rect(double a) {
		return a*a;
	}
	//오버로딩 직사각형 넓이
	double rect(double a, double b) {
		return a*b;
	}
	//오버로딩 직육면체의 넓이를 리턴
	double rect(double a, double b, double c) {
		return a*b*c;
	}
	
}
