package pac.abc; // 해당 클래스가 위치하는 패키지명이 꼭 알맞게 기재되어있어야한다.

public class Apple {

}
