package pac.def;

import java.util.Scanner;

//import pac.abc.Apple;
//import pac.abc.Banana;
import pac.abc.*; // 중간에 컨트롤+스페이스바 누르면 완성시켜줌. 아스타링크가 걸리면 저 패키지 안에 있는 클래스를 다 사용하겠다는 의미.

public class MainClass {
	
	public static void main(String[] args) {
		
		Melon m = new Melon();
		Apple a = new Apple(); //빨간줄이 뜨면 control +space bar 누르면 위치를 물어보는 내용이 뜸.
							   //그럼 여기서 임포트를 해주면 위에 import pac.abc.Apple; 이게 생성됨.
		Banana b = new Banana();
		
		Scanner scan = new Scanner(System.in);
		
		
		
		
	}

}
