package Quiz08;

public class MainClass {
	
	public static void main(String[] args) {
		
		Car c = new Car("GENESIS");
		c.run();
		
		
	}

}
