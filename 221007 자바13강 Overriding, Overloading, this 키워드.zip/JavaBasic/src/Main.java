import java.util.Arrays;

public class Main {
	
	public static void main(String[] args) {
		
		
		
	}//main
	
	 public int solution(int n) {
	        int answer = 0;
	        int count = 0;
	        7
	        
	        
	        return answer;
	    }
	
}//class
