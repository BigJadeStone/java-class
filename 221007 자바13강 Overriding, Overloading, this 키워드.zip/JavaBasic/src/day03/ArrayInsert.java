package day03;

import java.util.Arrays;
import java.util.Scanner;

public class ArrayInsert {
	
	public static void main(String[] args) {
		
		//배열의 한계점 - 크기가 고정
		//입력받은 문자열을 배열에 순서대로 저장.
		Scanner scan = new Scanner (System.in);
		String[] arr = new String[100];
		
		//"그만" 문자가 들어오기 전까지 입력.
		//next() 는 hello world 를 입력하면 공백 앞까지만 입력을 받아줌
		//nextline() 는 공백포함 문자열 전부 입력을 받아줌. 단 문제가있음.
		//nextline() 은 엔터값까지 받아주기 때문에 nextint 같은거랑 같이 쓰면 이런것들이 씹힌다는 문제가 발생.
		int count = 0; //인덱스를 나타내는 변수
		while(true) {
			System.out.println(">");
			String menu = scan.nextLine();
			
			if(menu.equals("그만")) {
				break;
			}
			
			arr[count] = menu; //저장
			count++; //인덱스 증가
		}//무한루프문
		
		String str = "[";
		
		//출력 - null이 안 나오게끔.
		for(int i = 0; i < count; i++) {
			str += arr[i];
			if(i == count -1) {
				str += "]";
				break;
			}
			str += ", ";
		}
		System.out.println(str);
	}//main

}
