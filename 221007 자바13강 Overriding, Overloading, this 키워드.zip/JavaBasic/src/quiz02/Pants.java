package quiz02;

public class Pants {
	
	//멤버 변수 설정
	String brand;
	String type;
	String itemNumber;
	String color;
	int size;
	
	//우선 기본생성자 생성
	Pants(){
		
	}
	//멤버변수를 매개변수로 담은 생성자
	Pants(String wBrand, String pType, String wItemNumber, String wColor, int hSize){
		brand = wBrand;
		type = pType;
		itemNumber = wItemNumber;
		color = wColor;
		size = hSize; 
	}
	//위 내용을 출력해줄 메서드 생성
	void info() {
		System.out.println("===바지 정보===");
		System.out.println("브랜드: " + brand);
		System.out.println("바지 종류: " + type);
		System.out.println("상품 번호: " + itemNumber);
		System.out.println("색상: " + color);
		System.out.println("사이즈: " + size);
	}
	
	int sizeCalculator(int tall, int weight ) {
		int yourSize = (tall*weight/1000)*2+2;
		return yourSize;
	}
	
	
	
}//class