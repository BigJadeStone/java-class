package day05;

public class Variable {
	
	//멤버변수 : 초기화를 하지 않으면 기본값으로 자동 초기화
	String a; // 파란색은 멤버
	//a = 10; 필드에서는 이런 문법 없음. 선언만 가능 
	
	void printNum(int c) {//매개변수는 지역변수의 일종
		int b = 10; //갈색갈 지역, 초기값이 지정이 되어야 사용가능
		System.out.println("멤버:" + a);
		System.out.println("지역:" + b);
		System.out.println("매개:" + c);
	}

}
