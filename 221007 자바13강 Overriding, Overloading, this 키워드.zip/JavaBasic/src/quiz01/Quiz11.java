package quiz01;
import java.util.Arrays;
import java.util.Scanner;

public class Quiz11 {
	
	public static void main(String[] args) {
		
		/*
		 * 첫행의 입력값은 배열의 크기가 됩니다.
		 * 배열의 크기만큼 반복을 돌면서, 입력받은 수들을 배열에 순서대로 저장.
		 * 5 -> 배열의 크기
		 * 10 -> arr[0]
		 * 20 -> arr[1]
		 * 30
		 * 40
		 * 50 -> arr[4]
		 * arr = [10, 20, 30, 40, 50}
		 * 배열만드는 법.
		 * int[] name = new int[만들배열 크기의 해당하는 숫자.];
		 * 혹은 int[] name = {1,2,3,4,5,6};
		 * array[넣을 배열의 위치에 해당하는 숫자,순서는 0부터 시작.] = 넣을 값;
		 * 배열의 길이를 보는 명령어.
		 * .length
		 * 배열의 모든 인덱스 값들을 보는 명령어.
		 * Arrays.toString(배열이름)
		 */
		System.out.print("배열크기 설정:");
		Scanner scan = new Scanner(System.in);
		int size = scan.nextInt();
		int[] num = new int[size];
		int i = 0;
		while(i<num.length) {
			System.out.print(">");
			int a = scan.nextInt();
			num[i] = a;
			i++;
		}
		System.out.println(Arrays.toString(num));
		
	}

}
