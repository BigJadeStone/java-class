package quiz01;
import java.util.Scanner;

public class StarDust {
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int line = scan.nextInt();
		
		for(int i=1; i <= line; i++) {
			/*
			 * n= 줄의 수.
			 * i=1 , 공백j =4 ,별k =1
			 * i=2 , 공백j =3 ,별k =2
			 * i=3 , 공백j =2 ,별k =3
			 * i=4 , 공백j =1 ,별k =4
			 * i=5 , 공백j =0 ,별k =5
			 */
			//공백을 나타내주는 애.
			for(int j=1; j <=line-i; j++) {
				System.out.print(" ");
			}
			//별을 찍어주는 놈.
			for(int k=1; k <= i ; k++) {
				System.out.print("*");
			}
				System.out.println(); //줄바꿈.
		}
		
		
		
		
		
	}

}
