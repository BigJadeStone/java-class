package day07.modi.member.pac2;

public class MainClass {

}
