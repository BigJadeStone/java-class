package day06.super_;

public class Person {

	
	
}
