package day06.super_;

public class MainClass {
	
	public static void main(String[] args) {
		
		
		
	}

}
