package practice;

public class MainClass {
	
	public static void main(String[] args) {
		
		
		
	}//main
	
	
	
}//class
