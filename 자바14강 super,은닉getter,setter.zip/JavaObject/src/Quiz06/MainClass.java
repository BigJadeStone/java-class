package Quiz06;

public class MainClass {
	
	public static void main(String[] args) {
		
		Calculator cal = new Calculator();
		//cal.add(5);
		System.out.println(cal.add(5));
		cal.circle(5);
		System.out.println(cal.circle(5));
		
		System.out.println("===================");
		
		Computer com = new Computer();
		com.circle(5);
		System.out.println("원의 넓이: " + com.circle(5));
		com.rect(5);
		System.out.println("정사각형 넓이: " + com.rect(5));
		com.rect(3,5);
		System.out.println("직사강형 넓이: " + com.rect(3,5));
		com.rect(3,4,5);
		System.out.println("직육면체 넓이: " + com.rect(3,4,5));
		
		
		
	}//main

}//class
