import java.util.Scanner;

import day01.SystemOut;

public class ArraysProblem {
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt();
		int[] arr = new int[n]; // n개의 정수를 담을 배열(=상자)
		
		// n개의 정수를 만들어 담은 배열.
		for(int i = 0; i < arr.length; i++ ) {
			int num = scan.nextInt();
			arr[i] = num;
		}
			
		int min = arr[0]; //최소값
		int max = arr[0]; //최대값
			
		//최대값 , 최소값 구하는 for문.
		for(int j = 0; j < arr.length  ; j++) {
			if(min > arr[j]) min = arr[j];
			if(max < arr[j]) max = arr[j];
		}
	System.out.println(min + " " + max);
		
		
		
		
//		이제 배열을 오름차순으로 정렬하기.
//		for(int j = 0; j < arr.length -1; j++) {
//			for(int k = j+1 ; k < arr.length; k++) {
//				if(arr[j] > arr[k]){//오름차순으로 하기. -> 부등호로 정함.
//					int temp = arr[j];
//					arr[j] = arr[k];
//					arr[k] = temp;
//				}
//			}
//		}
//		//System.out.println(Arrays.toString(arr));
//		System.out.println(arr[0] + " " + arr[arr.length-1]);
			
//		System.out.print(num + " ");
		
	}//main 
}