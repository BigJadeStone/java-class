
public class JavaPractice01 {
	
	public static void main(String[] args) {
		
		System.out.println(java(5));
		
	}//main
	
	static String java(int n) {
		
		String java = "";
		for(int i = 1; i <= n; i++) {
			if(i%2 != 0) {
				java += "자";
			} else {
				java += "바";
			}
			
		}
		return java;
	}
	
}//class
