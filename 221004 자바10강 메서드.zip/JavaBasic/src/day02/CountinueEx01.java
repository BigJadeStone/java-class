package day02;

public class CountinueEx01 {

	public static void main(String[] args) {
		
//		for(int i = 1; i <= 10; i++) {
//			
//			if(i % 2 == 1) {//홀수
//				continue; //다음 반복으로 pass : 즉 아래의 내용들은 건더띄고 바로 다음 반복회차로 넘어감.
//			}
//			
//			System.out.println(i);
//		}

		int i = 1; // 이거랑
		while(i <= 10) {
			if(i%2 == 1) {
				i++; //i의 증감식 위치를 주의해서 넣어줘야함.
				continue;
				//return; //이 자리에서 바로 메인의 종료.
			}
			System.out.println(i);
			i++;
		}
		System.out.println("프로그램 정상 종료");
	}//main

}
