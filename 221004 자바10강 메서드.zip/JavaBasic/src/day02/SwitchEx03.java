package day02;

public class SwitchEx03 {
	
	public static void main(String[] args) {
		
		String[] arr = {"안녕" , "hello", "사요나라", "#@$"};
		
		//System.outprintln(arr[0])
		/*
		 * Math.random()을 사용해서 배열의 인덱스 범위(0~3) 까지 랜덤수를 만듭니다.
		 * 랜덤수를 배열의 index의 적용해서 출력된 단어가  한국어, 영어, 일본어, 알수없는언어
		 * 인지 처리를 해보세요.
		 */
		
		int num = (int)(Math.random()*4);
		
		// 스위치 () 괄호 안에 들어갈 수 있는 것은 정수,문자 뿐이다.
		switch (num) {
		case 0:
			System.out.println(arr[0]);
			break;
		case 1:
			System.out.println(arr[1]);
			break;
		case 2:
			System.out.println(arr[2]);
			break;
		
		default:
			System.out.println(arr[3]);
			break;
		}
		
		
		
		
		
		
	}
		
}
