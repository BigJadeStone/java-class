import java.util.Scanner;

public class Quiz17 {
	
	public static void main(String[] args) {
		
		/*
		 * up down 게임
		 * 1~100까지의 임의 숫자를 1번 생성
		 * 반복문안에서 스캐너를 이용해서 정답을 입력받습니다.
		 * 
		 * 랜덤수가 입력받은 값보다 작으면 "더 큰수를 입력하세요"
		 * 랜덤수가 입력받은 값보다 크면 "더 작은수를 입력하세요"
		 * 
		 * 정답이라면 시도횟수: x회 를 출려갛고 종료
		 */
		
		int answer = (int)(Math.random()*100)+1;
		
		Scanner scan = new Scanner(System.in);
		int count = 0; // i를 while문 안에다 넣으면 계속 i=1로 초기화됨.
		while(true) {
			System.out.print("정답입력>");
			int num = scan.nextInt();
			count++; // 입력을 받았으면 시도를 1번 했다는 의미이니까 count 증가식 위치를 여기다.
			if(num < answer) System.out.println("더 큰수를 입력하세요");
			if(num > answer) System.out.println("더 작은수를 입력하세요");
			if(num == answer) {
				System.out.println("정답입니다");
				System.out.println("시도횟수: " + count);
				break;
			}
			
		}
		scan.close();
	}//main

}
