package day03;

import java.util.Arrays;

public class ArraySort {
	
	public static void main(String[] args) {
		
		//정렬 -> 7가지 방법 있음. 다 알 필요는 없음. 
		//		 선택정렬(조금 느린편이지만 가장 쉬운 정렬 방법 -> 프로그램이 커지면 너무느려진다는게 단점.), 퀵정렬(이진탐색도 여기 속함)
		// https://bangu4.tistory.com/206 정렬 알고리즘 참고 사이트.
		
		int [] arr = {5, 23, 1, 43, 100, 200, 40};
//		for(int i = 0; i < arr.length - 1; i++) { //요거는 선택정렬하는 내용.
//			for(int j = i + 1; j < arr.length; j++) { j= i + 1 이 되어야하는 이유는. i가 들어가야 이 for문이 돌아가기 때문.
//				if(arr[i] < arr[j]) {//오름차순, 내림차순 결정해주는 부등호!
//					int temp = arr[i];
//					arr[i] = arr[j];
//					arr[j] = temp;
//				}
//			}
//		}
		Arrays.sort(arr); //가장 빠른 정렬 실행도구.
		System.out.println(Arrays.toString(arr));
		
		
		
	}//main

}
