
public class Main {
	
	public static void main(String[] args) {
		
		
		
	}//main
	
    public int solution(int age) {
        int answer = 0;
        int year = 2022;
        for(int i =1 ; i <= age; i++){
            year -= 1;
        }
        answer = year;
        return answer;
    }
	    }
	}	
	
}//class
