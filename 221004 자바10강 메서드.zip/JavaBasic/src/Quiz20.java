import java.util.Arrays;
import java.util.Scanner;

public class Quiz20 {
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		/*
		 * ABC -> 한글자씩 char 배열에 저장.
		 */
		
		// 1st
//		String str = "ABC";
//		char[] arr = new char[str.length()];
//		
//		for(int i = 0; i < str.length(); i++) {
//			arr[i] = str.charAt(i);
//		}
//		
//		//2nd
//		char[] arr2 = "ABC".toCharArray();
//		System.out.println(Arrays.toString(arr2));
		
//		System.out.println(str.charAt(0));
//		System.out.println(str.charAt(1));
//		System.out.println(str.charAt(2));
		
		
		
		
		
		
		
		/*
		 * 첫번째 입력받은 값을 한글자씩 char형으로 출력
		 * ABC -> A B C
		 * A -> A
		 * AAA -> A A A 
		 */
		
//		String abc = scan.next();
//		char[] arr1 = abc.toCharArray();
//		System.out.println(Arrays.toString(arr1));
		
		
//		for(int i = 0; i < arr2.length; i++) {
//			System.out.print(arr2[i] + " ");
//		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*
		 * 두 문자열을 입력받습니다.
		 * 첫 입력에 알파벳이 주어집니다.
		 * 두번째 입력에는 알파벳으로 만들어진 문자열이 주어집니다.
		 * -> B
		 * -> BAABDSBDSAB
		 * 첫번째 입력된 알파벳이 두번째 입력에 몇개 포함되어 있는지 출력.
		 */
		
		String a = scan.next();
		String b = scan.next();
		char c = a.charAt(0);
		
		int count = 0;
		for(int i = 0; i < b.length(); i++) {
			
			if(b.charAt(i) == c ) {
				count++;
			}
			
		}
		System.out.println(count);
		
	}

}
