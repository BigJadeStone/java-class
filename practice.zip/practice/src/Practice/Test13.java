package Practice;

import java.util.Scanner;

public class Test13 {
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		String input = scan.nextLine();
		
		
		
		
		
		
		
		
		
		
		
	}

}
