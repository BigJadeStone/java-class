package Practice;

import java.util.Scanner;

public class Test4 {
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.println("값을 입력하시오");
		String input = scan.nextLine();
		
		int A = Integer.parseInt(input.split(" ")[0]);
		int B = Integer.parseInt(input.split(" ")[1]);
		int C = Integer.parseInt(input.split(" ")[2]);
		int D = Integer.parseInt(input.split(" ")[3]);
		int E = Integer.parseInt(input.split(" ")[4]);
		int F = Integer.parseInt(input.split(" ")[5]);
		int X = Integer.parseInt(input.split(" ")[6]);
		
		
		//로직.
		/*
		 * Takahashi : 초속 B미터 A초간 걷고 C초간 휴식한다.
		 *  B*A초 걷고 0*C초 쉼
		 * Aoki : 초속 E미터 D초간 걷고 F초 동안 휴식.
		 *  E*D초 걷고 0*F초 쉼
		 *  X초 지났을 때. 누가 더 멀리 갔는가?
		 *  같은 거리 갔으면 Draw 인쇄한다.
		 */
		String result = "";
		
		int tm = 0; // 다카하시가 간 거리.
		int am = 0; // 아오키가 간 거리.
		
		for(int i = 1; i <= X; i++) {
			if(i<=A) {
				tm += B;
			} else {
				tm += 0;
			}
		}
		
		for(int i = 1; i <= X; i++) {
			if(i<=A) {
				am += E;
			} else {
				am += 0;
			}
		}
		
		if(tm > am) {
			result = "Takahashi";
		} else if(tm < am) {
			result = "Aoki";
		} else if(tm == am) {
			result = "Draw";
		}
		
		//출력.
		System.out.println(result);
		
		
		
	}

}
