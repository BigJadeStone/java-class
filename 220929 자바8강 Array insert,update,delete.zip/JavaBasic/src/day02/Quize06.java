package day02;

import java.util.Scanner;

public class Quize06 {
	
	public static void main(String[] args) {
		
		//입력3개
		//결과를 출력하기 ( 스위치 구문을 이용해서)
		Scanner scan = new Scanner(System.in);
		
		System.out.print("정수1>");
		int num1 = scan.nextInt();
		System.out.print("연산을 선택하세요[+,-,*,/]");
		String type = scan.next();
		System.out.print("정수2>");
		int num2 = scan.nextInt();
			
		
		switch (type) {
		case "+":
			System.out.println("결과:" + (num1+num2));
			break;
		case "-":
			System.out.println("결과:" + (num1-num2));
			break;
		case "*":
			System.out.println("결과:" + (num1*num2));
			break;

		default:
			System.out.println("결과:" +( num1/num2));
			break;
		}
		
		scan.close();
		
		
		
		
	}

}
