package day02;

public class MultiForEx02 {
	public static void main(String[] args) {
		
		//회전할 때마다 횟수가 변화는 중첩반복문
		/*
		 * 		*
		 * 	   ***
		 * 	  *****
		 *   *******
		 *  ********* 
		 */ 
		int star = 5;
		for(int i = 1; i <= star; i++) {
			
			//공백을 만들어주는 애.
			//행 i= 1,2,3,4,5 일떄 
			//공백 j= 0,4,3,2,1 
			//그럼 규칙을 도출해보면? 5-i=j
			// 위에 star변수를 추가해보니 규칙은 star-i=j 로 됨.
			for(int j = 1; j <= star-i; j++) {
				System.out.print(" ");
			}
			
			//별을 찍어주는 애
			for(int j = 1; j <= i*2-1; j++) {//j의 반복 횟수는 밖의 i의 값에 따라 달라진다.
				System.out.print("*");
			}
			System.out.println();//줄 바꿈.
		}
		
		System.out.println("----------------------------------");
		
		int space = 5;
		// 밖의 for문은 행수를 결정.
		for(int a = 1; a <= space; a++) {
			//공백을 만들어주는 애.
			for(int b = 1; b<=a-1; b++ ) {
				System.out.print(" ");
			}
			
			//별을 찍어주는 애.
			for(int c = 1; c <= 2*(space-a)+1; c++) {
				System.out.print("*");
			}
			System.out.println(); //줄바꿈
			/*
			 *  a가1일 때, 공백b 1, 별c 9개 
			 *  a가2일 때, 공백b 2, 별c 7개 
			 *  a가3일 때, 공백b 3, 별c 5개  
			 *  a가4일 때, 공백b 4, 별c 3개
			 *  a가5일 때, 공백b 5, 별c 1개
			 */
		}
		
		
		
	}

}
