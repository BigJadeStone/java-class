import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		int[] arr = new int[9];
		for(int i = 0; i < arr.length; i++) {
			int num = scan.nextInt();
			arr[i] = num; //순서대로 배열에 정수 넣기.
			
		}
		
	}//main

}
