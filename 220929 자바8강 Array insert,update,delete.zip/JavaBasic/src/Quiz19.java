import java.util.Arrays;
import java.util.Scanner;

public class Quiz19 {

	public static void main(String[] args) {
		
		//망해버린 나의 문제 풀이 .. Quiz 19 Solution 보고 공부하기. 익숙해질때까지 본다.
		
		/*
		 * 1. 사람수(정수)를 입력을 받습니다.
		 * 2. 입력받은 사람수 만큼 랜덤한 배열을 생성해서 중복되지 않게 랜덤값을 저장
		 * 
		 * 랜덤값 크기 1 <= x <= 사람수
		 * 힌트> 집어넣기전에 집어넣기 직전까지 중복값이 있는지 확인.
		 *
		 * 3. 중복되지 않는 배열이 생성 되었다면, ○문자를 이용해서 배열의 크기를 출력(ㅁ 한자9)
		 * 4. 스캐너를 통해서 랜덤으로 배정된 좌석을 선택할 수 있습니다.
		 * 5. 제대로 선택된 좌석이면 자리번호를 공개하고 출력.
		 * 	  제대로 선택되지 않은 좌석이면 다시 선택을 출력.
		 * 
		 * 힌트> 선택된 자리는 0으로 변경
		 * 
		 * 출력내용 ex)
		 * 배정할 좌석의 크기를 지정하세요> 5
		 * [5, 4, 3, 1, 2]
		 */
		
		Scanner scan = new Scanner(System.in);
		//System.out.print("배정할 좌석의 크기를 지정하세요>");
		int size = scan.nextInt(); // 사람수 : 좌석의 갯수.
		
		int[] arr = new int[size];
		
		for(int i = 0; i < arr.length; i++) { //i는 좌석위치.
			arr[i] = (int)(Math.random()*size)+1;
			for(int j = 0; j < i; j++  ) {
				if(arr[j] == arr[i]) i--;
			}
		} 
		//System.out.println(Arrays.toString(arr)); // 여기까지 중복없는 배열문 만들기 끝. 표시구문.
		
		
		System.out.println();//줄바꿈
		
		
		//System.out.println(Arrays.toString(one)); //여기까지 동그라미로 좌석 크기 나타냄.
		// 이제 선택 좌석에 맞춰서 동그라미 색 바꾸기 설정.
		// 좌석선택1 -> arr[1] 값을 공개.
		
		String white = "○";
		String black = "●";
		String[] one = new String[size];
		boolean flag = false;
		for(int index = 0; index < one.length; index++) {//좌석 0표시 
			one[index] = white;
		}
		
		while(true) {
			
			System.out.println("-------------------좌석 선택 프로그램-------------------");
			
			for(int l = 1; l <= arr.length; l++) {//좌석 크기 숫자로 나타냄
				System.out.print(l + " ");
			}
			System.out.println(); //줄바꿈.
			
			//남은 좌석 현황 출력
			for(int i = 0; i < one.length, i++) {
				System.out.println(one[i] + " ");
			}
			
			System.out.print("좌석 선택 :");
			int choice = scan.nextInt();
			//System.out.println("자리번호를 공개합니다:" + arr[choice-1]);
			
			//arr[choice] 랑 one[choice] 가 같으면 one[choice]에 black 넣기 
			for(int i = 0; i < one.length; i++){
				if(choice-1 == i) {
					one[i] = black;
					flag = true;
				} 
			}
			
			if(flag) {
				System.out.println("자리번호를 공개합니다:" + arr[choice - 1]);
			} else if(false){
				System.out.println("다시 선택하시오.");
			}
			
		}//무한루프 
		
		
		
	}//main

}
