package quiz02;

public class MainClass {
	
	public static void main(String[] args) {
		
		/*
		 * Person클래스 를 파일로 정의
		 * 
		 * 멤버변수는 int age, String name
		 * 메서드 info() : String - 멤버변수를 문자열로 더해서 반환
		 * 
		 * 메인에서는 Person 객체를 2개 생성해서 각각 확인
 		 */
		
		//1. 객체생성
		Person per1 = new Person();
		//2. .로 사용
		per1.age = 18;
		per1.name = "goni";
		System.out.println(per1.info());
		
		System.out.println("===========");
		
		Person per2 = new Person();
		
		per2.age = 18;
		per2.name = "goni";
		System.out.println(per2.info());
		
	}

}
