package quiz02;

public class Person {
	
	int age;
	String name;
	
	String info() {
		//String a = age + " " + name;
		return age + " " + name;
	}

}
