package quiz01;
import java.util.Scanner;

public class Quiz22 {
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		method1();
		
		System.out.println(method2("오레노라멘"));
		
		System.out.println(method3(5,10,9.999));
		
		System.out.print("홀짝 정수 입력>");
		int a = scan.nextInt();
		System.out.println(method4(a));
		
		method5("오라", 10);
		
		System.out.println();
		System.out.println(abs(-5000));
		
		
	}//main
	
	static void method1() {
		System.out.println("안녕");
	}
	
	static String method2(String a) {
		return a;
	}
	
	static double method3(int a, int b, double c) {
		return a + b + c;
	}
	
	static String method4(int a) {
		if (a%2 == 0) {
			return "짝수";
		} else {
			return "홀수";
		}
	}
	
	static void method5(String a, int b) {
		for(int i = 1; i <= b; i++) {
			System.out.print(a+"");
		}
	}
	
	static int maxNum() { // 그냥 () 안에 int a, int b 넣어서 해도 됨.
		Scanner scan = new Scanner(System.in);
		System.out.print("정수 입력1>");
		int num1 = scan.nextInt();
		System.out.print("정수 입력2>");
		int num2 = scan.nextInt();
		
		//아래와 다른 또다른 방법. 
		//return a>b ? a : b;
		if(num1 > num2) {
			return num1;
		} else if(num1 < num2) {
			return num2;
		} else {
			return -1;
		}
		
	}
	
	static int abs(int a) {
		if(a < 0) {
			return -a;
		} else {
			return a;
		}
	}
	
}//class
