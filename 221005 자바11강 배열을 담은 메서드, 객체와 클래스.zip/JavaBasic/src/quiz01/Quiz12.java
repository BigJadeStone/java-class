package quiz01;
import java.util.Scanner;

public class Quiz12 {
	
	public static void main(String[] args) {
		//for~~~>
		//1. 7~100까지 정수 중의 7의 배수를 가로로  출력
		//2. 1~200까지 정수중의 9의 배수의 개수를 출력
		//3. 50~100까지 두 수 사이의 합
		//4. char변수를 활용해서 A~Z까지 출력, A=65, Z=90
		//5. 어떤수를 입력받아서 입력받은 수의 구구단 출력.
		
		System.out.println("#1번 문제");
		//1. 7~100까지 정수 중의 7의 배수를 가로로  출력
		for(int i=7; i<=100; i+=7) {
			//if(i%7 == 0) {
				System.out.print(i + " ");
			//}
		}
		
		System.out.println("");
		System.out.println("#2번 문제");
		//2. 1~200까지 정수중의 9의 배수의 개수를 출력
		int count = 0;
		for(int a=1; a<=200; a++) {
			if(a%9 == 0) {
				count++;
			}
		}
		System.out.println(count);
		int sum = 0;
		System.out.println("#3번 문제");
		//3. 50~100까지 두 수 사이의 합
		for(int b=50; b<=100; b++) {
			sum += b;
		}
		System.out.println(sum);
		
		System.out.println("#4번 문제");
		//4. char변수를 활용해서 A~Z까지 출력, A=65, Z=90
		// char 이름 = 숫자 -> 아스키 코드표에서 해당하는 숫자의 문자값으로 바뀌어서 표현됨.
		for(char munza = 65; munza <=90; munza++ ) //for(char munza = 'A'; munza <='Z'; munza++ ) 
		{
			System.out.print(munza + " ");
		}
		
		System.out.println("");
		System.out.println("#5번 문제");
		//5. 어떤수를 입력받아서 입력받은 수의 구구단 출력.
		Scanner scan = new Scanner(System.in);
		System.out.print("구구단 수:");
		int gugu = scan.nextInt();
		for(int c=1; c<=9; c++) {
		System.out.println(gugu +" X "+ c + " = " + gugu*c);
		}
		
		
	}

}
