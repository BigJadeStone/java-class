package day01;
import java.util.Scanner;

public class ScannerEx {

	public static void main(String[] args) {
		//1. 스캐너 생성
		Scanner scan = new Scanner(System.in);
		
		//next(), nextLine(), nextInt(), nextDouble() 
		System.out.print("입력>");
		String name = scan.next();
		
		System.out.print("입력>");
		int age = scan.nextInt();
		
		System.out.println(name + "이고," + age);
		
		scan.close(); //스캐너 자원 끝! (단, 닫으면 이후에 scanner사용 못함)
		
		
	}
}
