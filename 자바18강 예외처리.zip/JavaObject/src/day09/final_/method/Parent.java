package day09.final_.method;

public /*final 상속금지*/ class Parent {
	
	public void method01() {}
	public final void method02() {} //오버라이딩 금지
	
	

}
