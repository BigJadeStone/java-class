package day09.inter.basic3;

public class Tiger extends Animal{
	@Override
	public void eat() {
		System.out.println("호랑이는 고기를 먹어요.");
	}
}
