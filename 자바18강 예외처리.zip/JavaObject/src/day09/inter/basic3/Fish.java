package day09.inter.basic3;

public abstract class Fish {//부모
	
	public abstract void swim();
	
}
