package day09.inter.basic3;

public class Shark extends Fish{

	@Override
	public void swim() {
		System.out.println("상어는 바다에서 놀아요.");
	}
	
	
	
}
