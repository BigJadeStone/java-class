package day09.inter.herit;

//인터페이스간 상속은 extends 키워드를 사용
public interface Inter3 extends Inter1, Inter2{
	
	void some05();

}
