package Quiz13;

public class MainClass {
	
	public static void main(String[] args) {
		
		Shape r = new Rect("사각형", 5);
		//Rect r = new Rect("사각형", 5); 위랑 완전히 같은 의미
		Shape c = new Circle("원", 4 );
		//Circle c = new Circle("원",4); 위랑 완전히 같은 의미
		
		System.out.println(r.getName()); // 상속
		System.out.println(r.getArea()); // 오버라이딩
		System.out.println(c.getName()); // 상속
		System.out.println(c.getArea()); // 오버라이딩
		
		
	}

}
