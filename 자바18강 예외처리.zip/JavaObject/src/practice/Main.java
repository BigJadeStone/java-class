package practice;

import java.util.Arrays;

public class Main {
	
	public static void main(String[] args) {
		
		System.out.println(Arrays.toString(solution(10)));
		
		
	}//main
	
    public static int[] solution(int n) {
    	int[] answer = new int[10000];
    	int count = 0;
        for(int i = 1; i<= n; i++ ) {
        	if(n%i == 0) {
        		answer[count] = i;
        		count ++;
        	}
        }
        
        
        return answer;
    }
	
	
	
}//class
