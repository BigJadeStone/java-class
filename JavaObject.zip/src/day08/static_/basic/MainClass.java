package day08.static_.basic;


public class MainClass {

	public static void main(String[] args) {
		
		//PrintArray pt = new PrintArray();
		
		int[] arr = {1,2,3,4,5 };
		System.out.println( PrintArray.toArray(arr) );
				
		//Arrays ar = new Arrays();
		//System.out.println( Arrays.toString(arr) );
		
	}
}
