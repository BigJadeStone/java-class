package day09.inter.inherit;

public interface Inter1 {

	void some01();
	void some02();
	
}
