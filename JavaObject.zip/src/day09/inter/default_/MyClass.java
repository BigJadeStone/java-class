package day09.inter.default_;

public class MyClass implements MyInter {

	@Override
	public void some1() {
		System.out.println("some1오버라이딩");
	}

}
