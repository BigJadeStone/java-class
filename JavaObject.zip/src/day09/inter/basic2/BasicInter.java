package day09.inter.basic2;

import day09.inter.basic.Inter1;

public interface BasicInter {
	//클래스가 가져야할 메서드를 interface에 정의
	void insert(int a);
	void info();
	String getInfo();
	int delete(int a);
}
