package day09.inter.basic3;

public abstract class Animal {

	public abstract void eat();
}
