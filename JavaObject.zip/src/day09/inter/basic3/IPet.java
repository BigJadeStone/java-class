package day09.inter.basic3;

public interface IPet {

	void play(); //....
}
