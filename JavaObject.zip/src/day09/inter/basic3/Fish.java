package day09.inter.basic3;

public abstract class Fish {

	public abstract void swim();
}
