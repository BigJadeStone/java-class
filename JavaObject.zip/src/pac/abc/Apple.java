package pac.abc; //최상단부에 패키지 위치 선언(자동)

public class Apple {

}
