package day07.modi.cls.pac2;

import day07.modi.cls.pac1.*;

public class B {

	//A클래스 접근 - default는 같은 패키지에서만 접근가능
//	A a = new A();
	
}
