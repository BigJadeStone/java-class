package day07.modi.cls.pac1;

//클래스에 붙는 접근제어자는 public, default
class A {

}
