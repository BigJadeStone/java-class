package day07.modi.construct.pac2;

import day07.modi.construct.pac1.A;

public class C {

	A a = new A(10); //ok
//	A b = new A(true); //no - default
//	A c = new A("a"); //no - private
	
}
