package day07.modi.construct.pac1;

public class B {

	A a = new A(10); //ok
	A b = new A(true); //ok
//	A c = new A("a"); //no - private
	
}
