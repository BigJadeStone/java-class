package day07.encap.good;

public class MainClass {

	public static void main(String[] args) {
		
		MyBirth me = new MyBirth();
		me.setYear(2022); //set
		int year = me.getYear(); //get
		
		me.setMonth(12); //set
		int month = me.getMonth(); //get
		
		me.setDay(15); //set
		int day = me.getDay(); //get
		
		System.out.println(year + "년" + month + "월" + day + "일");
		
		
	}
}
