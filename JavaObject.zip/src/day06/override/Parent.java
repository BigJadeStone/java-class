package day06.override;

public class Parent {

	void method01() {
		System.out.println("부모님 1번 메서드");
	}
	
	int method02() {
		System.out.println("부모님 2번 메서드");
		return 0;
	}
}
