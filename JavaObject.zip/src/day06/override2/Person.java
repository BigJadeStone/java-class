package day06.override2;

public class Person { //부모클래스로 사용

	String name;
	int age;
	
	String info() {
		return "이름:" + name + ", 나이:" + age;
	}
	
}
