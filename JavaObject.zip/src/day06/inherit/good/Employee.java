package day06.inherit.good;

public class Employee extends Person {

	String department; //부서
	
}
