package quiz07;

import java.util.Arrays;

public class MainClass {

	public static void main(String[] args) {
		
		PrintArray pt = new PrintArray();
		
		int[] arr = {1,2,3,4,5 };
		System.out.println( pt.toArray(arr) );
		System.out.println( Arrays.toString(arr) );
		
		
	}
}
