package quiz01;
import java.util.Scanner;

public class Quiz04 {

	public static void main(String[] args) {
		
		/*
		 * 정수를 하나 입력받습니다.
		 * 입력받은 값이 0인지, 홀수인지, 짝수인지, 음수인지 구별하는 elseif문
		 */
		
		Scanner scan = new Scanner(System.in);
		System.out.print("정수>");
		int num = scan.nextInt();
		
		if(num == 0) {
			System.out.println("0입니다");
		} else if(num < 0) {
			System.out.println(num + "은 음수 입니다");
		} else if(num % 2 == 0) {
			System.out.println(num + "은 짝수 입니다");
		} else {
			System.out.println(num + "은 홀수 입니다");
		}
		
		scan.close();
		
		
	}
}
