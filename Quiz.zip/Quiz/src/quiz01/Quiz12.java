package quiz01;
import java.util.Scanner;

public class Quiz12 {

	public static void main(String[] args) {
		//for~~~>
		
		//1. 7~100까지 정수 중의 7의 배수를 가로로 출력
		for(int i = 7; i <= 100; i+=7) {
			System.out.print(i + " ");
		}
		System.out.println();
		//2. 1~200까지 정수중의 9의 배수의 개수를 출력
		int count = 0;
		for(int i = 1; i <= 200; i++) {
			if(i % 9 == 0) {
				count++;
			}
		}
		System.out.println(count);
		
		//3. 50~100까지 두 수 사이의 합
		int sum = 0;
		for(int i = 50; i <= 100; i++) {
			sum += i;
		}
		System.out.println(sum);
		//4. char변수를 활용해서 A~Z까지 출력, A=65, Z=90
		for(char c = 'A'; c <= 'Z'; c++) {
			System.out.print(c);
		}
		System.out.println();
		
		//5. 어떤수를 입력받아서 입력받은 수의 구구단 출력.
		Scanner scan = new Scanner(System.in);
		System.out.print("단>");
		int dan = scan.nextInt();
		
		for(int i = 1; i <= 9; i++) {
			System.out.println(dan + " x " + i + " = " + dan*i);
		}
		
		
		
		
		
		
	}
}
