package quiz01;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;

public class Quiz23 {

	public static void main(String[] args) {
	
//		int a = 1;
//		int b = 2;
//		double c = 3.14;
//		double r = method3(a, b, c);
//		System.out.println(r);
		
		char[] arr = {'a', 'b', 'c' };

		String result = method06(arr); //변수명
		System.out.println(result);
		
		int[] arr2 = {1,2,3};
		int result2 = method07(arr2);
		System.out.println(result2);
		
		String[] arr3 = method08("홍길동", "이순신");
		System.out.println(Arrays.toString(arr3));
		
	} //////////////////////////////////////////
	
	//char배열의 요소를 문자열로 붙여라
	static String method06(char[] arr) {
		String str = "";
		for(int i = 0; i < arr.length; i++) {
			str += arr[i];
		}
		return str;
	}
	//int배열의 합
	static int method07(int[] arr) {
		int sum = 0;
		for(int a : arr ) {
			sum += a;
		}
		return sum;
	}
	//배열리턴
	static String[] method08(String a, String b) {
		String[] arr = {a, b};
		return arr;
	}
	
	
	
	
	
//	static double method3(int a, int b, double c) {
//		double d = a + b + c;
//		return d;
//	}
	
	
	
}
