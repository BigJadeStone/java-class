package quiz08;

public class MainClass {

	public static void main(String[] args) {
		Car car = new Car("공차");
		car.run();
		
	}
	
	
	
}
