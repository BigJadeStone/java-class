package quiz06;

public class Calculator {
	int result; 
	double pi = 3.14;
	
	int add(int i) {
		result += i;
		return result;
	}
	
	double circle(int r) {
		return r * r * pi;
	}
	
}
