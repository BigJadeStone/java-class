package quiz07;

public class PrintArray {

	String toArray(int[] arr) {
		
		String str ="[";
		
		for(int i = 0; i < arr.length; i++ ) {
			str += arr[i];
			if(i == arr.length - 1) {
				str += "]";
				break;
			}
			str += ", ";
		}
		
		return str; 
	}
		
	String toArray(char[] arr) {
		
		String str ="[";
		
		for(int i = 0; i < arr.length; i++ ) {
			str += arr[i];
			if(i == arr.length - 1) {
				str += "]";
				break;
			}
			str += ", ";
		}
		
		return str; 
	}
	
	String toArray(String[] arr) {
		
		String str ="[";
		
		for(int i = 0; i < arr.length; i++ ) {
			str += arr[i];
			if(i == arr.length - 1) {
				str += "]";
				break;
			}
			str += ", ";
		}
		
		return str; 
	}
	
	
	
	
	
}
