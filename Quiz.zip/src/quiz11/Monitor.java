package quiz11;

public class Monitor {

	public void info() {
		System.out.println("----모니터 정보----");
		System.out.println("from LG");
	}
}
