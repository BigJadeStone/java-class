package quiz11;

public class MainClass {

	public static void main(String[] args) {
		
		Computer com = new Computer();
		com.computerInfo();
		
		//6
		Monitor m = com.getMonitor();
		m.info();
		
		
	}
}
