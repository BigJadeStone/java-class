package quiz01;
import java.util.Arrays;
import java.util.Scanner;

public class Quiz19_ {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("좌석>");
		int size = scan.nextInt();
		
		int[] arr = new int[size];
		
		int index = 0; //현재 위치변수
		이름:while(true) {
			int seat = (int)(Math.random() * size) + 1; //1~size 랜덤수
			for(int i = 0; i < index; i++) {
				if(arr[i] == seat) continue 이름;
			}
			arr[index] = seat;
			index++;
			if(index == size) break;
		}

		
		//좌석 출력
		int count = 0;
		while(true) {
			
			for(int i = 0; i < arr.length; i++) {
				System.out.printf("%-3d" , i+1); //%-3d = 3자리 공간을 잡고 왼쪽부터 채움
			}
			System.out.println();
			for(int i = 0; i < arr.length; i++) {
				if(arr[i] == 0) {
					System.out.printf("%-3s" ,"● ");
				} else {
					System.out.printf("%-3s" ,"○ ");
				}
				
			}
			System.out.println();
			
			System.out.print("좌석선택>");
			int seat = scan.nextInt();
			
			if(arr[seat-1] == 0) {
				System.out.println("제대로 선택하실래요?");
			} else {
				System.out.println("선택좌석:" + arr[seat-1]);
				arr[seat-1] = 0;
				count++; //좌석 선택시 카운트증가
			}
			
			
			if(count == size) {
				System.out.println("종료합니다");
				break; //탈출
			}
		}
		
		
		
		
		
		
		
		
		
	}
}
