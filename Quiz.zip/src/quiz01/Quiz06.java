package quiz01;
import java.util.Scanner;

public class Quiz06 {

	public static void main(String[] args) {
		//입력 3개
		//결과 출력
		Scanner scan = new Scanner(System.in);

		System.out.print("정수1>");
		int n1 = scan.nextInt();
		
		System.out.print("연산을 선택하세요[+, -, *, /]>");
		String oper = scan.next();
		
		System.out.print("정수2>");
		int n2 = scan.nextInt();
		
		switch (oper) {
		case "+":
			System.out.println("결과:" + (n1 + n2));
			break;
		case "-":
			System.out.println("결과:" + (n1 - n2));
			break;
		case "*":
			System.out.println("결과:" + (n1 * n2));
			break;
		case "/":
			System.out.println("결과:" + (n1 / n2));
			break;

		default:
			System.out.println("[+, -, *, /]를 입력하세요");
			break;
		}
		
		
		
		
	}
}
