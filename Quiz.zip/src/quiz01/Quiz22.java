package quiz01;

public class Quiz22 {

	public static void main(String[] args) {
		
		double d = method3(1, 2, 3.14);
		System.out.println(d);
		
		String s = method4(5);
		System.out.println(s);
		
		method5("가", 4);
		
		String result = java(5);
		System.out.println(result);
		
		int num = sum(5);
		System.out.println(num);
	}

	static void method1() {
		System.out.println("안녕");
	}
	
	static String method2(String s) {
		return s;
	}
	
	static double method3(int a, int b, double c) {
		double d = a + b + c;
		return d;
	}
	
	static String method4(int n) {
		if(n % 2 == 0) {
			return "짝수";
		} else {
			return "홀수";
		}
	}
	
	static void method5(String s, int n) {
		for(int i = 1; i <= n; i++) {
			System.out.println(s);
		}
	}
	
	static int maxNum(int a, int b) {
		return a > b ? a : b;
	}
	static int abs(int n) {
		if(n > 0) {
			return n;
		} else {
			return -n;
		}
	}
	
	static String java(int n) {
		String s = "";
		for(int i = 1; i <= n; i++) {
			if(i % 2 == 1) { //i = 1, 3 ,5, 7....
				s += "자";
			} else { //i = 2, 4, 6, 8....
				s += "바";
			}
		}
		return s;
	}
	
	static int sum(int n) {
		int sum = 0;
		for(int i = 1; i <= n; i++) {
			if(n % i == 0) {
				sum += i;
			}
		}
		return sum;
	}
	
	
	
}
