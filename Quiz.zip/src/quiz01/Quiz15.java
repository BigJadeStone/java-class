package quiz01;

public class Quiz15 {

	public static void main(String[] args) {

		//힌트 -> 출력은 가로 or 세로로만 가능합니다
		//정렬은 \t -> 8칸 띄어쓰기 

		for(int i = 1; i <= 9; i+=3) {
			
			for(int j = 1; j <= 9; j++) {
				System.out.print(i +   " x " + j + " = " + i*j + "\t");
				System.out.print(i+1 + " x " + j + " = " + (i+1)*j + "\t");
				System.out.print(i+2 + " x " + j + " = " + (i+2)*j);
				
				System.out.println(); //줄바꿈
			}
			
			System.out.println();  //줄바꿈
			
		}
		
		
	}
}
