package quiz12;

public class Tv extends Product {
	//가격 400원 이름은 tv
	//get, set메서드는 자동으로 상속됩니다
	public Tv() {
		super(400, "tv");
	}
}
