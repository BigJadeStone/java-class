package quiz04;

public class MainClass {

	public static void main(String[] args) {
		
		Warrior war = new Warrior("강한친구");
		war.bash();
		war.bash();
		
		Wizard wi = new Wizard("대한육군");
		wi.iceArrow();
	}
}
