package quiz15;

public class BugsMusic implements SongList {
	
	private String[] list = new String[100];
	private int count = 0;
	
	/* SongList인터페이스를 상속받습니다.
	 * 마음대로 작성.
	 */
	@Override
	public void insertList(String song) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void playList() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public int playLength() {
		// TODO Auto-generated method stub
		return 0;
	}
	

	
}
