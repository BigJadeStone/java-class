package quiz02;

public class MainClass {

	public static void main(String[] args) {
		
		/*
		 * Person클래스 를 파일로 정의
		 * 
		 * 멤버변수는 int age, String name
		 * 메서드 info() : String - 회원정보를 문자열로 더해서 ★반환
		 * 
		 * 메인에서는 Person 객체를 2개 생성해서 각각 확인
		 */
		
		//1. 객체생성
		Person p = new Person();
		//2. .로 사용
		p.age = 20;
		p.name = "홍길동";
		String result = p.info();
		System.out.println(result);
		
		
		Person p2 = new Person();
		p2.age = 30;
		p2.name = "이순신";
		String result2 = p2.info();
		System.out.println(result2);
		
		
		Person p3 = new Person("홍길동", 40);
		
		////////////////////////////////////////////////
		//멤버변수, 메서드, 생성자를 사용해서 
		//현실에 찾아볼 수 있는 물건 생각해서 표현.
		//생성해서 사용 - 메서드 2개이상
		Tv tv = new Tv();
		
		tv.power();
		tv.changeCh(10); 
		tv.power();
		
		
		
		
		
		
		
		
		
		
	}
}
