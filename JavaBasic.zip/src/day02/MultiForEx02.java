package day02;

import java.util.Scanner;

public class MultiForEx02 {

	public static void main(String[] args) {
		
		//회전할 때마다 횟수가 변화는 중첩반복문
		/*
		 *     *
		 *    ***
		 *   *****
		 *  *******
		 * *********
		 */
		int star = 5;
		for(int i = 1; i <= star; i++) {
			
			//공백
			for(int j = 1; j <= star-i; j++) {
				System.out.print(" ");
			}
			
			//별
			for(int j = 1; j <= i*2-1; j++) {
				System.out.print("*");
			}
			
			System.out.println();//줄바꿈
		}

		System.out.println("------------------------------------");
		/*				i   공백j 별j
		 * *********    1    0    9    
		 *  *******     2    1    7
		 *   *****      3    2	  5
		 *    ***       4    3    3
		 *     *        5    4    1
		 */
		
		for(int i = 1; i <= star; i++) {
			
//			for(int j = 1; j <= i-1; j++ ) {
//				System.out.print(" ");
//			} 
			
			for(int j = 1; j <= 2*(star-i) + 1; j++) {
				System.out.print("*");
			}
			
			System.out.println();
		}
		
		
		/*			i   j(공백) j(별)
		 *     *    1     4     1
		 *    **    2     3     2
		 *   ***    3	  2     3
		 *  ****    4     1     4
		 * *****    5     0     5
		 * 
		 */
		
		System.out.println("------------------------------------");
		
		Scanner scan = new Scanner(System.in);
		int num = scan.nextInt();
		
		for(int i = 1; i <= num; i++) {
			
			for(int j = 1; j <= num-i; j++) {
				System.out.print(" ");
			}
			for(int j = 1; j <= i; j++) {
				System.out.print("*");
			}
			
			System.out.println();
		}
		
		
		
		
		
		
		
	}
}
