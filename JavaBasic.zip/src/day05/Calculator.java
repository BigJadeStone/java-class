package day05;

public class Calculator {
	
	int result;
	int add(int n) {
		result += n;
		return result;
	}
	
}
