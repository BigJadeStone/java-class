package java_1024;

import java.util.Arrays;

public class ArrayTask {
	
	public static void main(String[] args) {
		//문자열 배열 생성
		String [] ar = {"카리나", "아이린", "윈터", "조이" , "슬기"};
		
		//배열을 순회하면서 출력
		/*
		for(String singer : ar) {
			System.out.println(singer);
		}
		*/
		
		//문자열의 크기 비교 하는 메서드 : compareTo, compareToIgnorecase
		//System.out.println(ar[1].compareTo(ar[0]));
		
		//선택 정렬
		//1.배열의 복제
		String[] copyAr = Arrays.copyOf(ar, ar.length);
		
		
		//선택정렬 -> 성능이 굉장히 떨어지기에 실무에서는 안 씀.
		//첫번째 부터 n-1 번째 데이터까지
		for(int i=0; i<copyAr.length-1; i++) {
			//자신의 뒤에 있는 모든 데이터와 비교해서
			for(int j=i+1; j<copyAr.length; j++) {
				//뒤에 있는 데이터가 더 크다면 교환
				if(copyAr[i].compareTo(copyAr[j])<0) {// 부등호 방향만 바꾸면 오름차순 내림차순 변경 - 양수이면 왼쪽이 큰거. 같으면 0, 오른쪽이 크면 음수.
					String temp = copyAr[i];
					copyAr[i] = copyAr[j];
					copyAr[j] = temp;
				}
			}
		}
		
		System.out.println(Arrays.toString(copyAr));
		
		
		
		
		
	}

}
